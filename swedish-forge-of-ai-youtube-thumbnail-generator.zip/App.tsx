
import React, { useState, useCallback, useEffect, useRef, useMemo } from 'react';
import Header from './components/Header';
import TextInput from './components/TextInput';
import ImageInput from './components/ImageInput';
import Button from './components/Button';
import { generateThumbnail, correctSpelling } from './services/geminiService';
import { generateClientSideThumbnails } from './services/clientImageService';
import TextareaInput from './components/TextareaInput';
import { HistoryEntry } from './types';
import * as historyService from './services/historyService';
import { fileToBase64, dataURLtoFile } from './utils/imageUtils';
import HistoryPanel from './components/HistoryPanel';
import SelectInput from './components/SelectInput';
import SkeletonLoader from './components/SkeletonLoader';
import CheckboxInput from './components/CheckboxInput';
import FontSelect from './components/FontSelect';
import ToggleSwitch from './components/ToggleSwitch';
import QuotaStatus from './components/QuotaStatus';
import ImageModal from './components/ImageModal';

interface GeneratedImageGroup {
  baseImage?: string;
  thumbnails: string[];
}

const getAspectRatio = (size: string): string => {
  switch (size) {
    case '1280x720':
    case '1920x1080':
      return '16:9 landscape';
    case '720x1280':
      return '9:16 portrait';
    case '1080x1080':
      return '1:1 square';
    default:
      return '16:9 landscape';
  }
};

const getFontDescription = (fontFamily: string): string => {
  const descriptions: { [key: string]: string } = {
    'impact': 'a very bold, condensed, sans-serif font like Impact',
    'anton': 'a bold, sans-serif display font like Anton',
    'bebas_neue': 'a popular uppercase, condensed sans-serif font like Bebas Neue',
    'lobster': 'a bold, rounded, script-like font like Lobster',
    'pacifico': 'a smooth, rounded, cursive script font like Pacifico',
    'permanent_marker': 'a font that looks like a thick permanent marker',
    'rock_salt': 'a font that looks like rough, handwritten brush strokes',
    'bangers': 'a classic, bold, comic-book style font',
    'oswald': 'a classic, condensed, sans-serif font like Oswald',
    'roboto': 'a clean, modern, geometric sans-serif font like Roboto',
    'montserrat': 'a geometric sans-serif font popular in web design',
    'playfair_display': 'an elegant, high-contrast serif font',
  };
  return descriptions[fontFamily] || `a font that looks like '${fontFamily.replace(/_/g, ' ')}'`;
};

const getTextEffectsPrompt = (
    textEffects: { outline: boolean; glow: boolean; drop_shadow: boolean },
    outlineThickness: string, outlineColor: string, outlineStyle: string,
    glowColor: string, glowRadius: string,
    shadowColor: string
): string => {
    const effectPrompts = [];
    if (textEffects.outline) {
        effectPrompts.push(`a distinct ${outlineThickness} ${outlineColor} outline (style: ${outlineStyle})`);
    }
    if (textEffects.glow) {
        effectPrompts.push(`a vibrant ${glowColor} glow (radius: ${glowRadius})`);
    }
    if (textEffects.drop_shadow) {
        effectPrompts.push(`a soft ${shadowColor} drop shadow for depth`);
    }

    if (effectPrompts.length === 0) {
        return 'The text must be highly readable but should NOT have any extra effects like outlines, glows, or shadows.';
    }

    return `To make the text pop, apply these critical effects: ${effectPrompts.join(' and ')}.`;
};


const App: React.FC = () => {
  const initialFormState = useMemo(() => {
    try {
        const savedState = localStorage.getItem('thumbnailFormState');
        if (savedState) {
            return JSON.parse(savedState);
        }
    } catch (e) {
        console.error("Failed to load form state from localStorage:", e);
        localStorage.removeItem('thumbnailFormState');
    }
    return {}; // Return empty object if nothing is saved or on error
  }, []);

  const [title, setTitle] = useState(initialFormState.title ?? '');
  const [titleHistory, setTitleHistory] = useState<string[]>(initialFormState.titleHistory ?? []);
  const [isTitleHistoryOpen, setIsTitleHistoryOpen] = useState(false);
  const titleHistoryRef = useRef<HTMLDivElement>(null);

  const [text, setText] = useState(initialFormState.text ?? '');
  const [textHistory, setTextHistory] = useState<string[]>(initialFormState.textHistory ?? []);
  const [isTextHistoryOpen, setIsTextHistoryOpen] = useState(false);
  const textHistoryRef = useRef<HTMLDivElement>(null);

  const [theme, setTheme] = useState(initialFormState.theme ?? '');
  const [themeHistory, setThemeHistory] = useState<string[]>(initialFormState.themeHistory ?? []);
  const [isThemeHistoryOpen, setIsThemeHistoryOpen] = useState(false);
  const themeHistoryRef = useRef<HTMLDivElement>(null);
  
  // Font State
  const [titleFontFamily, setTitleFontFamily] = useState(initialFormState.titleFontFamily ?? 'impact');
  const [textFontFamily, setTextFontFamily] = useState(initialFormState.textFontFamily ?? 'roboto');
  const [titleFontSize, setTitleFontSize] = useState(initialFormState.titleFontSize ?? 'extra_large');
  const [textFontSize, setTextFontSize] = useState(initialFormState.textFontSize ?? 'medium');
  
  // Text Styling State
  const [textAlign, setTextAlign] = useState(initialFormState.textAlign ?? 'center');
  const [lineSpacing, setLineSpacing] = useState(initialFormState.lineSpacing ?? 'normal');
  const [textPosition, setTextPosition] = useState(initialFormState.textPosition ?? 'bottom-center');


  // Text Effects State
  const [textEffects, setTextEffects] = useState(initialFormState.textEffects ?? {
    outline: true,
    glow: false,
    drop_shadow: false,
  });
  const [outlineThickness, setOutlineThickness] = useState(initialFormState.outlineThickness ?? 'medium');
  const [outlineColor, setOutlineColor] = useState(initialFormState.outlineColor ?? 'black');
  const [outlineStyle, setOutlineStyle] = useState(initialFormState.outlineStyle ?? 'solid');
  const [glowColor, setGlowColor] = useState(initialFormState.glowColor ?? 'yellow');
  const [glowRadius, setGlowRadius] = useState(initialFormState.glowRadius ?? 'normal');
  const [shadowColor, setShadowColor] = useState(initialFormState.shadowColor ?? 'black');
  const [shadowOffsetX, setShadowOffsetX] = useState(initialFormState.shadowOffsetX ?? '4px');
  const [shadowOffsetY, setShadowOffsetY] = useState(initialFormState.shadowOffsetY ?? '4px');
  const [shadowBlurRadius, setShadowBlurRadius] = useState(initialFormState.shadowBlurRadius ?? '6px');
  
  // Text Background State
  const [textBackgroundShape, setTextBackgroundShape] = useState(initialFormState.textBackgroundShape ?? 'none');
  const [textBackgroundColor, setTextBackgroundColor] = useState(initialFormState.textBackgroundColor ?? 'black');
  const [textBackgroundOpacity, setTextBackgroundOpacity] = useState(initialFormState.textBackgroundOpacity ?? '75%');

  // New Image Size State
  const [imageSize, setImageSize] = useState(initialFormState.imageSize ?? '1280x720');

  // Multi-image upload state
  const [uploadedImages, setUploadedImages] = useState<File[]>([]);
  const [uploadedImagePreviews, setUploadedImagePreviews] = useState<string[]>([]);
  const [youtubeUrl, setYoutubeUrl] = useState(initialFormState.youtubeUrl ?? '');
  const [isFetchingThumbnail, setIsFetchingThumbnail] = useState(false);


  // AI vs Client-side generation
  const [useAiImageEditing, setUseAiImageEditing] = useState(initialFormState.useAiImageEditing ?? true);
  
  // New AI features
  const [removeBackground, setRemoveBackground] = useState(initialFormState.removeBackground ?? false);
  const [smartPlacement, setSmartPlacement] = useState(initialFormState.smartPlacement ?? '');
  const [keepOriginalPhoto, setKeepOriginalPhoto] = useState(initialFormState.keepOriginalPhoto ?? false);


  const [generatedImages, setGeneratedImages] = useState<GeneratedImageGroup[] | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isHistoryLoading, setIsHistoryLoading] = useState(true);
  const [isCorrectingSpelling, setIsCorrectingSpelling] = useState(false);
  const [isCorrectingTextSpelling, setIsCorrectingTextSpelling] = useState(false);
  const [isCorrectingThemeSpelling, setIsCorrectingThemeSpelling] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [selectedImage, setSelectedImage] = useState<{ url: string; fileName: string } | null>(null);

  // Rate Limiting State
  const apiCallTimestampsRef = useRef<number[]>([]);
  const [requestsThisMinute, setRequestsThisMinute] = useState(0);

  const resultsRef = useRef<HTMLDivElement>(null);

  const fontOptions = [
    { value: 'default', label: 'Default (AI Choice)' },
    { value: 'abril_fatface', label: 'Abril Fatface' },
    { value: 'aclonica', label: 'Aclonica' },
    { value: 'acme', label: 'Acme' },
    { value: 'actor', label: 'Actor' },
    { value: 'adamina', label: 'Adamina' },
    { value: 'advent_pro', label: 'Advent Pro' },
    { value: 'aguafina_script', label: 'Aguafina Script' },
    { value: 'akronim', label: 'Akronim' },
    { value: 'aladin', label: 'Aladin' },
    { value: 'aldrich', label: 'Aldrich' },
    { value: 'alef', label: 'Alef' },
    { value: 'alegreya', label: 'Alegreya' },
    { value: 'alfa_slab_one', label: 'Alfa Slab One' },
    { value: 'allerta_stencil', label: 'Allerta Stencil' },
    { value: 'almarai', label: 'Almarai' },
    { value: 'amarante', label: 'Amarante' },
    { value: 'amaranth', label: 'Amaranth' },
    { value: 'amatic_sc', label: 'Amatic SC' },
    { value: 'amethysta', label: 'Amethysta' },
    { value: 'amiko', label: 'Amiko' },
    { value: 'amiri', label: 'Amiri' },
    { value: 'amita', label: 'Amita' },
    { value: 'anaheim', label: 'Anaheim' },
    { value: 'andada', label: 'Andada' },
    { value: 'andika', label: 'Andika' },
    { value: 'angledana', label: 'Angledana' },
    { value: 'annie_use_your_telescope', label: 'Annie Use Your Telescope' },
    { value: 'anonymous_pro', label: 'Anonymous Pro' },
    { value: 'antar', label: 'Antar' },
    { value: 'antic', label: 'Antic' },
    { value: 'anton', label: 'Anton' },
    { value: 'antonio', label: 'Antonio' },
    { value: 'anybody', label: 'Anybody' },
    { value: 'arapey', label: 'Arapey' },
    { value: 'arbutus', label: 'Arbutus' },
    { value: 'architects_daughter', label: 'Architects Daughter' },
    { value: 'archivo', label: 'Archivo' },
    { value: 'archivo_black', label: 'Archivo Black' },
    { value: 'archivo_narrow', label: 'Archivo Narrow' },
    { value: 'aref_ruqaa', label: 'Aref Ruqaa' },
    { value: 'arima_madurai', label: 'Arima Madurai' },
    { value: 'arimo', label: 'Arimo' },
    { value: 'arizonia', label: 'Arizonia' },
    { value: 'armata', label: 'Armata' },
    { value: 'arsenal', label: 'Arsenal' },
    { value: 'artifika', label: 'Artifika' },
    { value: 'arvo', label: 'Arvo' },
    { value: 'arya', label: 'Arya' },
    { value: 'asap', label: 'Asap' },
    { value: 'asar', label: 'Asar' },
    { value: 'asset', label: 'Asset' },
    { value: 'assistant', label: 'Assistant' },
    { value: 'astloch', label: 'Astloch' },
    { value: 'asul', label: 'Asul' },
    { value: 'atma', label: 'Atma' },
    { value: 'atomic_age', label: 'Atomic Age' },
    { value: 'aubrey', label: 'Aubrey' },
    { value: 'audiowide', label: 'Audiowide' },
    { value: 'autour_one', label: 'Autour One' },
    { value: 'average', label: 'Average' },
    { value: 'azeret_mono', label: 'Azeret Mono' },
    { value: 'b612', label: 'B612' },
    { value: 'bad_script', label: 'Bad Script' },
    { value: 'bahiana', label: 'Bahiana' },
    { value: 'bai_jamjuree', label: 'Bai Jamjuree' },
    { value: 'bakbak_one', label: 'Bakbak One' },
    { value: 'baloo_2', label: 'Baloo 2' },
    { value: 'balsamiq_sans', label: 'Balsamiq Sans' },
    { value: 'balthazar', label: 'Balthazar' },
    { value: 'bangers', label: 'Bangers' },
    { value: 'barlow', label: 'Barlow' },
    { value: 'barlow_condensed', label: 'Barlow Condensed' },
    { value: 'barriecito', label: 'Barriecito' },
    { value: 'barrio', label: 'Barrio' },
    { value: 'basic', label: 'Basic' },
    { value: 'baskervville', label: 'Baskervville' },
    { value: 'battambang', label: 'Battambang' },
    { value: 'baumans', label: 'Baumans' },
    { value: 'bayon', label: 'Bayon' },
    { value: 'bebas_neue', label: 'Bebas Neue' },
    { value: 'belgrano', label: 'Belgrano' },
    { value: 'bellefair', label: 'Bellefair' },
    { value: 'belleza', label: 'Belleza' },
    { value: 'bellota', label: 'Bellota' },
    { value: 'benchnine', label: 'BenchNine' },
    { value: 'benne', label: 'Benne' },
    { value: 'benthan', label: 'Benthan' },
    { value: 'berkshire_swash', label: 'Berkshire Swash' },
    { value: 'besley', label: 'Besley' },
    { value: 'beth_ellen', label: 'Beth Ellen' },
    { value: 'bevan', label: 'Bevan' },
    { value: 'bigelow_rules', label: 'Bigelow Rules' },
    { value: 'bigshot_one', label: 'Bigshot One' },
    { value: 'bilbo', label: 'Bilbo' },
    { value: 'biorhyme', label: 'BioRhyme' },
    { value: 'biryani', label: 'Biryani' },
    { value: 'bitter', label: 'Bitter' },
    { value: 'black_ops_one', label: 'Black Ops One' },
    { value: 'blinker', label: 'Blinker' },
    { value: 'bodoni_moda', label: 'Bodoni Moda' },
    { value: 'bokor', label: 'Bokor' },
    { value: 'bonbon', label: 'Bonbon' },
    { value: 'bonheur_royale', label: 'Bonheur Royale' },
    { value: 'boogaloo', label: 'Boogaloo' },
    { value: 'bowlby_one_sc', label: 'Bowlby One SC' },
    { value: 'brawler', label: 'Brawler' },
    { value: 'bree_serif', label: 'Bree Serif' },
    { value: 'brygada_1918', label: 'Brygada 1918' },
    { value: 'bungee', label: 'Bungee' },
    { value: 'bungee_hairline', label: 'Bungee Hairline' },
    { value: 'butcherman', label: 'Butcherman' },
    { value: 'butterfly_kids', label: 'Butterfly Kids' },
    { value: 'cabin', label: 'Cabin' },
    { value: 'cabin_sketch', label: 'Cabin Sketch' },
    { value: 'caesar_dressing', label: 'Caesar Dressing' },
    { value: 'cagliostro', label: 'Cagliostro' },
    { value: 'cairo', label: 'Cairo' },
    { value: 'caladea', label: 'Caladea' },
    { value: 'calistoga', label: 'Calistoga' },
    { value: 'calligraffitti', label: 'Calligraffitti' },
    { value: 'cambo', label: 'Cambo' },
    { value: 'cambay', label: 'Cambay' },
    { value: 'caminite', label: 'Caminite' },
    { value: 'canterel', label: 'Canterel' },
    { value: 'cantata_one', label: 'Cantata One' },
    { value: 'cantora_one', label: 'Cantora One' },
    { value: 'capriola', label: 'Capriola' },
    { value: 'caramel', label: 'Caramel' },
    { value: 'carattere', label: 'Carattere' },
    { value: 'cardo', label: 'Cardo' },
    { value: 'carme', label: 'Carme' },
    { value: 'carter_one', label: 'Carter One' },
    { value: 'castoro', label: 'Castoro' },
    { value: 'catamaran', label: 'Catamaran' },
    { value: 'caudex', label: 'Caudex' },
    { value: 'caveat', label: 'Caveat' },
    { value: 'caveat_brush', label: 'Caveat Brush' },
    { value: 'cedarville_cursive', label: 'Cedarville Cursive' },
    { value: 'ceviche_one', label: 'Ceviche One' },
    { value: 'chakra_petch', label: 'Chakra Petch' },
    { value: 'changa', label: 'Changa' },
    { value: 'changa_one', label: 'Changa One' },
    { value: 'chango', label: 'Chango' },
    { value: 'charm', label: 'Charm' },
    { value: 'chathura', label: 'Chathura' },
    { value: 'chela_one', label: 'Chela One' },
    { value: 'chelsea_market', label: 'Chelsea Market' },
    { value: 'chenla', label: 'Chenla' },
    { value: 'cherish', label: 'Cherish' },
    { value: 'cherry_cream_soda', label: 'Cherry Cream Soda' },
    { value: 'cherry_swash', label: 'Cherry Swash' },
    { value: 'chewy', label: 'Chewy' },
    { value: 'chicle', label: 'Chicle' },
    { value: 'chilanka', label: 'Chilanka' },
    { value: 'chivo', label: 'Chivo' },
    { value: 'chonburi', label: 'Chonburi' },
    { value: 'cinzel', label: 'Cinzel' },
    { value: 'cinzel_decorative', label: 'Cinzel Decorative' },
    { value: 'clicker_script', label: 'Clicker Script' },
    { value: 'coda', label: 'Coda' },
    { value: 'coiny', label: 'Coiny' },
    { value: 'combo', label: 'Combo' },
    { value: 'comfortaa', label: 'Comfortaa' },
    { value: 'comforter', label: 'Comforter' },
    { value: 'comic_neue', label: 'Comic Neue' },
    { value: 'coming_soon', label: 'Coming Soon' },
    { value: 'commissioner', label: 'Commissioner' },
    { value: 'concert_one', label: 'Concert One' },
    { value: 'condiment', label: 'Condiment' },
    { value: 'content', label: 'Content' },
    { value: 'contrail_one', label: 'Contrail One' },
    { value: 'convergence', label: 'Convergence' },
    { value: 'cookie', label: 'Cookie' },
    { value: 'copse', label: 'Copse' },
    { value: 'corben', label: 'Corben' },
    { value: 'corinthia', label: 'Corinthia' },
    { value: 'cormorant', label: 'Cormorant' },
    { value: 'courgette', label: 'Courgette' },
    { value: 'cousine', label: 'Cousine' },
    { value: 'coustard', label: 'Coustard' },
    { value: 'covered_by_your_grace', label: 'Covered By Your Grace' },
    { value: 'crafty_girls', label: 'Crafty Girls' },
    { value: 'creepster', label: 'Creepster' },
    { value: 'crete_round', label: 'Crete Round' },
    { value: 'crimson_text', label: 'Crimson Text' },
    { value: 'croissant_one', label: 'Croissant One' },
    { value: 'crushed', label: 'Crushed' },
    { value: 'cuprum', label: 'Cuprum' },
    { value: 'cute_font', label: 'Cute Font' },
    { value: 'cutive', label: 'Cutive' },
    { value: 'damion', label: 'Damion' },
    { value: 'dancing_script', label: 'Dancing Script' },
    { value: 'dangrek', label: 'Dangrek' },
    { value: 'darker_grotesque', label: 'Darker Grotesque' },
    { value: 'david_libre', label: 'David Libre' },
    { value: 'dawning_of_a_new_day', label: 'Dawning of a New Day' },
    { value: 'days_one', label: 'Days One' },
    { value: 'dekko', label: 'Dekko' },
    { value: 'delius', label: 'Delius' },
    { value: 'della_respira', label: 'Della Respira' },
    { value: 'denk_one', label: 'Denk One' },
    { value: 'devonshire', label: 'Devonshire' },
    { value: 'dhurjati', label: 'Dhurjati' },
    { value: 'didact_gothic', label: 'Didact Gothic' },
    { value: 'diplomata', label: 'Diplomata' },
    { value: 'dongle', label: 'Dongle' },
    { value: 'doppio_one', label: 'Doppio One' },
    { value: 'dorsa', label: 'Dorsa' },
    { value: 'dosis', label: 'Dosis' },
    { value: 'dotgothic16', label: 'DotGothic16' },
    { value: 'dr_sugiyama', label: 'Dr Sugiyama' },
    { value: 'duru_sans', label: 'Duru Sans' },
    { value: 'dynalight', label: 'Dynalight' },
    { value: 'eagle_lake', label: 'Eagle Lake' },
    { value: 'east_sea_dokdo', label: 'East Sea Dokdo' },
    { value: 'eater', label: 'Eater' },
    { value: 'eb_garamond', label: 'EB Garamond' },
    { value: 'economica', label: 'Economica' },
    { value: 'eczar', label: 'Eczar' },
    { value: 'el_messiri', label: 'El Messiri' },
    { value: 'electrolize', label: 'Electrolize' },
    { value: 'elsie', label: 'Elsie' },
    { value: 'emblema_one', label: 'Emblema One' },
    { value: 'emilys_candy', label: 'Emilys Candy' },
    { value: 'engagement', label: 'Engagement' },
    { value: 'englebert', label: 'Englebert' },
    { value: 'enriqueta', label: 'Enriqueta' },
    { value: 'ephesis', label: 'Ephesis' },
    { value: 'epilogue', label: 'Epilogue' },
    { value: 'erica_one', label: 'Erica One' },
    { value: 'esteban', label: 'Esteban' },
    { value: 'estonia', label: 'Estonia' },
    { value: 'euphoria_script', label: 'Euphoria Script' },
    { value: 'ewert', label: 'Ewert' },
    { value: 'exo', label: 'Exo' },
    { value: 'exo_2', label: 'Exo 2' },
    { value: 'explora', label: 'Explora' },
    { value: 'fahkwang', label: 'Fahkwang' },
    { value: 'fanwood_text', label: 'Fanwood Text' },
    { value: 'farro', label: 'Farro' },
    { value: 'farsan', label: 'Farsan' },
    { value: 'fascinate', label: 'Fascinate' },
    { value: 'fascinate_inline', label: 'Fascinate Inline' },
    { value: 'faster_one', label: 'Faster One' },
    { value: 'fasthand', label: 'Fasthand' },
    { value: 'fauna_one', label: 'Fauna One' },
    { value: 'faustina', label: 'Faustina' },
    { value: 'federico_the_great', label: 'Federico the Great' },
    { value: 'federo', label: 'Federo' },
    { value: 'felipa', label: 'Felipa' },
    { value: 'fenix', label: 'Fenix' },
    { value: 'festivo', label: 'Festivo' },
    { value: 'finger_paint', label: 'Finger Paint' },
    { value: 'finishing_touch', label: 'Finishing Touch' },
    { value: 'fira_code', label: 'Fira Code' },
    { value: 'fjalla_one', label: 'Fjalla One' },
    { value: 'fjord_one', label: 'Fjord One' },
    { value: 'flamenco', label: 'Flamenco' },
    { value: 'flavors', label: 'Flavors' },
    { value: 'fleur_de_leah', label: 'Fleur De Leah' },
    { value: 'fondamento', label: 'Fondamento' },
    { value: 'fontdiner_swanky', label: 'Fontdiner Swanky' },
    { value: 'forum', label: 'Forum' },
    { value: 'francois_one', label: 'Francois One' },
    { value: 'frank_ruhl_libre', label: 'Frank Ruhl Libre' },
    { value: 'fraunces', label: 'Fraunces' },
    { value: 'freckle_face', label: 'Freckle Face' },
    { value: 'fredericka_the_great', label: 'Fredericka the Great' },
    { value: 'fredoka', label: 'Fredoka' },
    { value: 'fredoka_one', label: 'Fredoka One' },
    { value: 'freehand', label: 'Freehand' },
    { value: 'fresca', label: 'Fresca' },
    { value: 'frijole', label: 'Frijole' },
    { value: 'fruktur', label: 'Fruktur' },
    { value: 'fugaz_one', label: 'Fugaz One' },
    { value: 'fuggles', label: 'Fuggles' },
    { value: 'fuzzy_bubbles', label: 'Fuzzy Bubbles' },
    { value: 'gafata', label: 'Gafata' },
    { value: 'galada', label: 'Galada' },
    { value: 'galdeano', label: 'Galdeano' },
    { value: 'galindo', label: 'Galindo' },
    { value: 'gamja_flower', label: 'Gamja Flower' },
    { value: 'gantari', label: 'Gantari' },
    { value: 'gayathri', label: 'Gayathri' },
    { value: 'gelasio', label: 'Gelasio' },
    { value: 'gemunu_libre', label: 'Gemunu Libre' },
    { value: 'genos', label: 'Genos' },
    { value: 'gentium_basic', label: 'Gentium Basic' },
    { value: 'geo', label: 'Geo' },
    { value: 'georama', label: 'Georama' },
    { value: 'geostar', label: 'Geostar' },
    { value: 'gidugu', label: 'Gidugu' },
    { value: 'gilda_display', label: 'Gilda Display' },
    { value: 'girassol', label: 'Girassol' },
    { value: 'give_you_glory', label: 'Give You Glory' },
    { value: 'glass_antiqua', label: 'Glass Antiqua' },
    { value: 'glegoo', label: 'Glegoo' },
    { value: 'gloria_hallelujah', label: 'Gloria Hallelujah' },
    { value: 'glory', label: 'Glory' },
    { value: 'goblin_one', label: 'Goblin One' },
    { value: 'gochi_hand', label: 'Gochi Hand' },
    { value: 'goldman', label: 'Goldman' },
    { value: 'gorditas', label: 'Gorditas' },
    { value: 'gothic_a1', label: 'Gothic A1' },
    { value: 'gotu', label: 'Gotu' },
    { value: 'goudy_bookletter_1911', label: 'Goudy Bookletter 1911' },
    { value: 'gowun_batang', label: 'Gowun Batang' },
    { value: 'graduate', label: 'Graduate' },
    { value: 'grand_hotel', label: 'Grand Hotel' },
    { value: 'grandstander', label: 'Grandstander' },
    { value: 'gravitas_one', label: 'Gravitas One' },
    { value: 'great_vibes', label: 'Great Vibes' },
    { value: 'grenze', label: 'Grenze' },
    { value: 'griffy', label: 'Griffy' },
    { value: 'gruppo', label: 'Gruppo' },
    { value: 'gudea', label: 'Gudea' },
    { value: 'gugi', label: 'Gugi' },
    { value: 'gulzar', label: 'Gulzar' },
    { value: 'gupter', label: 'Gupter' },
    { value: 'gurajada', label: 'Gurajada' },
    { value: 'gwendolyn', label: 'Gwendolyn' },
    { value: 'habibi', label: 'Habibi' },
    { value: 'hachi_maru_pop', label: 'Hachi Maru Pop' },
    { value: 'hahmlet', label: 'Hahmlet' },
    { value: 'halant', label: 'Halant' },
    { value: 'hammersmith_one', label: 'Hammersmith One' },
    { value: 'handlee', label: 'Handlee' },
    { value: 'hanuman', label: 'Hanuman' },
    { value: 'happy_monkey', label: 'Happy Monkey' },
    { value: 'harmattan', label: 'Harmattan' },
    { value: 'headland_one', label: 'Headland One' },
    { value: 'heebo', label: 'Heebo' },
    { value: 'henny_penny', label: 'Henny Penny' },
    { value: 'hepta_slab', label: 'Hepta Slab' },
    { value: 'herr_von_muellerhoff', label: 'Herr Von Muellerhoff' },
    { value: 'hi_melody', label: 'Hi Melody' },
    { value: 'hina_mincho', label: 'Hina Mincho' },
    { value: 'hind', label: 'Hind' },
    { value: 'holtwood_one_sc', label: 'Holtwood One SC' },
    { value: 'homemade_apple', label: 'Homemade Apple' },
    { value: 'homenaje', label: 'Homenaje' },
    { value: 'ibm_plex_sans', label: 'IBM Plex Sans' },
    { value: 'iceberg', label: 'Iceberg' },
    { value: 'iceland', label: 'Iceland' },
    { value: 'imbue', label: 'Imbue' },
    { value: 'impact', label: 'Impact' },
    { value: 'imprima', label: 'Imprima' },
    { value: 'inconsolata', label: 'Inconsolata' },
    { value: 'inder', label: 'Inder' },
    { value: 'indie_flower', label: 'Indie Flower' },
    { value: 'inika', label: 'Inika' },
    { value: 'inknut_antiqua', label: 'Inknut Antiqua' },
    { value: 'inria_sans', label: 'Inria Sans' },
    { value: 'inter', label: 'Inter' },
    { value: 'irish_grover', label: 'Irish Grover' },
    { value: 'island_moments', label: 'Island Moments' },
    { value: 'istok_web', label: 'Istok Web' },
    { value: 'italiana', label: 'Italiana' },
    { value: 'italianno', label: 'Italianno' },
    { value: 'itim', label: 'Itim' },
    { value: 'jacques_francois', label: 'Jacques Francois' },
    { value: 'jalandhar', label: 'Jalandhar' },
    { value: 'jallalla', label: 'Jallalla' },
    { value: 'jalsa', label: 'Jalsa' },
    { value: 'jambono', label: 'Jambono' },
    { value: 'jaro', label: 'Jaro' },
    { value: 'jetbrains_mono', label: 'JetBrains Mono' },
    { value: 'jim_nightshade', label: 'Jim Nightshade' },
    { value: 'joan', label: 'Joan' },
    { value: 'jockey_one', label: 'Jockey One' },
    { value: 'jolly_lodger', label: 'Jolly Lodger' },
    { value: 'jomhuria', label: 'Jomhuria' },
    { value: 'jomolhari', label: 'Jomolhari' },
    { value: 'josefin_sans', label: 'Josefin Sans' },
    { value: 'josefin_slab', label: 'Josefin Slab' },
    { value: 'joti_one', label: 'Joti One' },
    { value: 'jua', label: 'Jua' },
    { value: 'judson', label: 'Judson' },
    { value: 'julee', label: 'Julee' },
    { value: 'julius_sans_one', label: 'Julius Sans One' },
    { value: 'junge', label: 'Junge' },
    { value: 'jura', label: 'Jura' },
    { value: 'just_another_hand', label: 'Just Another Hand' },
    { value: 'k2d', label: 'K2D' },
    { value: 'kadwa', label: 'Kadwa' },
    { value: 'kaisei_decol', label: 'Kaisei Decol' },
    { value: 'kalam', label: 'Kalam' },
    { value: 'kameron', label: 'Kameron' },
    { value: 'kanit', label: 'Kanit' },
    { value: 'kantumruy', label: 'Kantumruy' },
    { value: 'karantina', label: 'Karantina' },
    { value: 'karma', label: 'Karma' },
    { value: 'katibeh', label: 'Katibeh' },
    { value: 'kaushan_script', label: 'Kaushan Script' },
    { value: 'kavivanar', label: 'Kavivanar' },
    { value: 'kavoon', label: 'Kavoon' },
    { value: 'kdam_thmor', label: 'Kdam Thmor' },
    { value: 'keania_one', label: 'Keania One' },
    { value: 'kelly_slab', label: 'Kelly Slab' },
    { value: 'kenia', label: 'Kenia' },
    { value: 'khand', label: 'Khand' },
    { value: 'khmer', label: 'Khmer' },
    { value: 'khula', label: 'Khula' },
    { value: 'kings', label: 'Kings' },
    { value: 'kirang_haerang', label: 'Kirang Haerang' },
    { value: 'kite_one', label: 'Kite One' },
    { value: 'klee_one', label: 'Klee One' },
    { value: 'knewave', label: 'Knewave' },
    { value: 'koho', label: 'KoHo' },
    { value: 'kodchasan', label: 'Kodchasan' },
    { value: 'koh_santepheap', label: 'Koh Santepheap' },
    { value: 'kolker_brush', label: 'Kolker Brush' },
    { value: 'kotta_one', label: 'Kotta One' },
    { value: 'koulen', label: 'Koulen' },
    { value: 'kranky', label: 'Kranky' },
    { value: 'kreon', label: 'Kreon' },
    { value: 'kristi', label: 'Kristi' },
    { value: 'krona_one', label: 'Krona One' },
    { value: 'krub', label: 'Krub' },
    { value: 'kufam', label: 'Kufam' },
    { value: 'kulim_park', label: 'Kulim Park' },
    { value: 'kumar_one', label: 'Kumar One' },
    { value: 'kumbh_sans', label: 'Kumbh Sans' },
    { value: 'kurale', label: 'Kurale' },
    { value: 'la_belle_aurore', label: 'La Belle Aurore' },
    { value: 'lacquer', label: 'Lacquer' },
    { value: 'laila', label: 'Laila' },
    { value: 'lakki_reddy', label: 'Lakki Reddy' },
    { value: 'lalezar', label: 'Lalezar' },
    { value: 'lancelot', label: 'Lancelot' },
    { value: 'langar', label: 'Langar' },
    { value: 'lateef', label: 'Lateef' },
    { value: 'lato', label: 'Lato' },
    { value: 'lavishly_yours', label: 'Lavishly Yours' },
    { value: 'league_gothic', label: 'League Gothic' },
    { value: 'league_script', label: 'League Script' },
    { value: 'league_spartan', label: 'League Spartan' },
    { value: 'leckerli_one', label: 'Leckerli One' },
    { value: 'ledger', label: 'Ledger' },
    { value: 'lekton', label: 'Lekton' },
    { value: 'lemon', label: 'Lemon' },
    { value: 'lemonada', label: 'Lemonada' },
    { value: 'lexend', label: 'Lexend' },
    { value: 'licorice', label: 'Licorice' },
    { value: 'life_savers', label: 'Life Savers' },
    { value: 'lilita_one', label: 'Lilita One' },
    { value: 'lily_script_one', label: 'Lily Script One' },
    { value: 'limelight', label: 'Limelight' },
    { value: 'linden_hill', label: 'Linden Hill' },
    { value: 'literata', label: 'Literata' },
    { value: 'livvic', label: 'Livvic' },
    { value: 'lobster', label: 'Lobster' },
    { value: 'lobster_two', label: 'Lobster Two' },
    { value: 'lora', label: 'Lora' },
    { value: 'luckiest_guy', label: 'Luckiest Guy' },
    { value: 'major_mono_display', label: 'Major Mono Display' },
    { value: 'maven_pro', label: 'Maven Pro' },
    { value: 'merriweather', label: 'Merriweather' },
    { value: 'merriweather_sans', label: 'Merriweather Sans' },
    { value: 'metal_mania', label: 'Metal Mania' },
    { value: 'monoton', label: 'Monoton' },
    { value: 'montserrat', label: 'Montserrat' },
    { value: 'nixie_one', label: 'Nixie One' },
    { value: 'notable', label: 'Notable' },
    { value: 'nunito', label: 'Nunito' },
    { value: 'old_standard_tt', label: 'Old Standard TT' },
    { value: 'open_sans', label: 'Open Sans' },
    { value: 'orbitron', label: 'Orbitron' },
    { value: 'oswald', label: 'Oswald' },
    { value: 'pacifico', label: 'Pacifico' },
    { value: 'passion_one', label: 'Passion One' },
    { value: 'patua_one', label: 'Patua One' },
    { value: 'paytone_one', label: 'Paytone One' },
    { value: 'permanent_marker', label: 'Permanent Marker' },
    { value: 'play', label: 'Play' },
    { value: 'playfair_display', label: 'Playfair Display' },
    { value: 'poppins', label: 'Poppins' },
    { value: 'press_start_2p', label: 'Press Start 2P' },
    { value: 'pt_sans', label: 'PT Sans' },
    { value: 'pt_serif', label: 'PT Serif' },
    { value: 'quantico', label: 'Quantico' },
    { value: 'quicksand', label: 'Quicksand' },
    { value: 'raleway', label: 'Raleway' },
    { value: 'ranchers', label: 'Ranchers' },
    { value: 'righteous', label: 'Righteous' },
    { value: 'roboto', label: 'Roboto' },
    { value: 'rock_salt', label: 'Rock Salt' },
    { value: 'rubik_mono_one', label: 'Rubik Mono One' },
    { value: 'russo_one', label: 'Russo One' },
    { value: 'rye', label: 'Rye' },
    { value: 'sacramento', label: 'Sacramento' },
    { value: 'sanchez', label: 'Sanchez' },
    { value: 'sarabun', label: 'Sarabun' },
    { value: 'satisfy', label: 'Satisfy' },
    { value: 'secular_one', label: 'Secular One' },
    { value: 'shadows_into_light', label: 'Shadows Into Light' },
    { value: 'shrikhand', label: 'Shrikhand' },
    { value: 'sigmar_one', label: 'Sigmar One' },
    { value: 'six_caps', label: 'Six Caps' },
    { value: 'slackey', label: 'Slackey' },
    { value: 'source_sans_pro', label: 'Source Sans Pro' },
    { value: 'special_elite', label: 'Special Elite' },
    { value: 'spectral', label: 'Spectral' },
    { value: 'squada_one', label: 'Squada One' },
    { value: 'sriracha', label: 'Sriracha' },
    { value: 'syne', label: 'Syne' },
    { value: 'tangerine', label: 'Tangerine' },
    { value: 'teko', label: 'Teko' },
    { value: 'titillium_web', label: 'Titillium Web' },
    { value: 'ubuntu', label: 'Ubuntu' },
    { value: 'ultra', label: 'Ultra' },
    { value: 'uncial_antiqua', label: 'Uncial Antiqua' },
    { value: 'varela_round', label: 'Varela Round' },
    { value: 'vidaloka', label: 'Vidaloka' },
    { value: 'vollkorn', label: 'Vollkorn' },
    { value: 'vt323', label: 'VT323' },
    { value: 'walter_turncoat', label: 'Walter Turncoat' },
    { value: 'yanone_kaffeesatz', label: 'Yanone Kaffeesatz' },
    { value: 'yellowtail', label: 'Yellowtail' },
    { value: 'zilla_slab', label: 'Zilla Slab' },
  ];
  
  const fontSizeOptions = [
    { value: 'small', label: 'Small' },
    { value: 'medium', label: 'Medium' },
    { value: 'large', label: 'Large' },
    { value: 'extra_large', label: 'Extra Large' },
  ];

  const imageSizeOptions = [
    { value: '1280x720', label: '1280x720 (16:9 YouTube Standard)' },
    { value: '1920x1080', label: '1920x1080 (16:9 HD)' },
    { value: '720x1280', label: '720x1280 (9:16 YouTube Shorts)' },
    { value: '1080x1080', label: '1080x1080 (1:1 Square)' },
  ];

  const outlineThicknessOptions = [
    { value: 'thin', label: 'Thin' },
    { value: 'medium', label: 'Medium' },
    { value: 'thick', label: 'Thick' },
  ];
  
  const outlineStyleOptions = [
    { value: 'solid', label: 'Solid' },
    { value: 'dashed', label: 'Dashed' },
    { value: 'dotted', label: 'Dotted' },
    { value: 'double', label: 'Double Line' },
    { value: 'glow', label: 'Glow Outline (AI Recommended)' },
    { value: 'sketchy', label: 'Sketchy / Hand-drawn (AI Only)' },
    { value: '3d', label: '3D Block (AI Only)' },
  ];

  const outlineColorOptions = [
    { value: 'black', label: 'Black' },
    { value: 'white', label: 'White' },
    { value: '#FF0000', label: 'Red' },
    { value: '#FFFF00', label: 'Yellow' },
    { value: '#0000FF', label: 'Blue' },
    { value: '#00FF00', label: 'Lime Green' },
    { value: '#FF00FF', label: 'Magenta' },
    { value: '#00FFFF', label: 'Cyan' },
    { value: '#FFA500', label: 'Orange' },
    { value: '#800080', label: 'Purple' },
    { value: '#FFC0CB', label: 'Pink' },
    { value: '#40E0D0', label: 'Turquoise' },
    { value: '#36454F', label: 'Charcoal' },
    { value: '#808080', label: 'Gray' },
    { value: '#A52A2A', label: 'Brown' },
    { value: '#006400', label: 'Dark Green' },
    { value: '#00008B', label: 'Dark Blue' },
    { value: '#8B0000', label: 'Dark Red' },
    { value: '#FFD700', label: 'Gold' },
    { value: '#C0C0C0', label: 'Silver' },
    { value: '#F5F5DC', label: 'Beige' },
    { value: '#E6E6FA', label: 'Lavender' },
  ];

  const glowColorOptions = [
    { value: 'yellow', label: 'Yellow' },
    { value: '#00FFFF', label: 'Cyan' },
    { value: '#FF00FF', label: 'Magenta' },
    { value: '#00FF00', label: 'Lime Green' },
    { value: '#FFA500', label: 'Orange' },
    { value: 'white', label: 'White' },
  ];

  const glowRadiusOptions = [
    { value: 'subtle', label: 'Subtle' },
    { value: 'normal', label: 'Normal' },
    { value: 'wide', label: 'Wide' },
  ];

  const shadowColorOptions = [
    { value: 'black', label: 'Black' },
    { value: 'darkgray', label: 'Dark Gray' },
    { value: '#4B0082', label: 'Indigo' },
    { value: '#8B0000', label: 'Dark Red' },
    { value: 'white', label: 'White' },
    { value: '#333333', label: 'Charcoal' },
  ];

  const shadowOffsetOptions = [
    { value: '-8px', label: 'Large Up/Left (-8px)' },
    { value: '-4px', label: 'Medium Up/Left (-4px)' },
    { value: '-2px', label: 'Small Up/Left (-2px)' },
    { value: '0px', label: 'None (0px)' },
    { value: '2px', label: 'Small Down/Right (2px)' },
    { value: '4px', label: 'Medium Down/Right (4px)' },
    { value: '8px', label: 'Large Down/Right (8px)' },
  ];

  const shadowBlurOptions = [
    { value: '0px', label: 'None / Hard (0px)' },
    { value: '2px', label: 'Subtle (2px)' },
    { value: '6px', label: 'Normal (6px)' },
    { value: '12px', label: 'Heavy (12px)' },
    { value: '20px', label: 'Very Heavy (20px)' },
  ];

  const textAlignOptions = [
    { value: 'left', label: 'Left' },
    { value: 'center', label: 'Center' },
    { value: 'right', label: 'Right' },
  ];

  const lineSpacingOptions = [
    { value: 'tight', label: 'Tight' },
    { value: 'normal', label: 'Normal' },
    { value: 'loose', label: 'Loose' },
  ];
  
  const backgroundShapeOptions = [
    { value: 'none', label: 'None' },
    { value: 'solid rectangle', label: 'Rectangle' },
    { value: 'pill shape', label: 'Pill / Rounded' },
    { value: 'subtle circle', label: 'Circle' },
    { value: 'underline bar', label: 'Underline Bar' },
    { value: 'ribbon / banner', label: 'Ribbon / Banner (AI Only)' },
    { value: 'hexagon', label: 'Hexagon (AI Only)' },
    { value: 'speech bubble', label: 'Speech Bubble (AI Only)' },
    { value: 'brush stroke', label: 'Brush Stroke (AI Only)' },
    { value: 'starburst shape', label: 'Starburst (AI Only)' },
    { value: 'abstract blob', label: 'Abstract Blob (AI Only)' },
  ];
  
  const backgroundColorOptions = [
    { value: 'black', label: 'Black' },
    { value: 'white', label: 'White' },
    { value: '#FF0000', label: 'Red' },
    { value: '#FFFF00', label: 'Yellow' },
    { value: '#0000FF', label: 'Blue' },
    { value: '#FF69B4', label: 'Pink' },
    { value: '#FFA500', label: 'Orange' },
    { value: '#800080', label: 'Purple' },
    { value: '#008080', label: 'Teal' },
    { value: '#FFD700', label: 'Gold' },
    { value: '#333333', label: 'Dark Gray' },
    { value: '#000080', label: 'Navy Blue' },
    { value: '#8B0000', label: 'Dark Red' },
    { value: '#228B22', label: 'Forest Green' },
  ];

  const backgroundOpacityOptions = [
    { value: '25%', label: 'Subtle (25%)' },
    { value: '50%', label: 'Medium (50%)' },
    { value: '75%', label: 'Strong (75%)' },
    { value: '100%', label: 'Solid (100%)' },
  ];

  const textPositionOptions = [
    { value: 'top-left', label: 'Top Left' },
    { value: 'top-center', label: 'Top Center' },
    { value: 'top-right', label: 'Top Right' },
    { value: 'middle-left', label: 'Middle Left' },
    { value: 'middle-center', label: 'Center' },
    { value: 'middle-right', label: 'Middle Right' },
    { value: 'bottom-left', label: 'Bottom Left' },
    { value: 'bottom-center', label: 'Bottom Center' },
    { value: 'bottom-right', label: 'Bottom Right' },
    { value: 'top-third-left', label: 'Top Third, Left' },
    { value: 'top-third-center', label: 'Top Third, Center' },
    { value: 'top-third-right', label: 'Top Third, Right' },
    { value: 'bottom-third-left', label: 'Bottom Third, Left' },
    { value: 'bottom-third-center', label: 'Bottom Third, Center' },
    { value: 'bottom-third-right', label: 'Bottom Third, Right' },
  ];

  useEffect(() => {
    // Simulate async to allow UI to show skeleton loader
    setTimeout(() => {
      setHistory(historyService.loadHistory());
      setIsHistoryLoading(false);
    }, 200);
  }, []);
  
  // When keepOriginalPhoto is enabled, disable background removal
  useEffect(() => {
    if (keepOriginalPhoto && removeBackground) {
        setRemoveBackground(false);
    }
  }, [keepOriginalPhoto, removeBackground]);


  // Effect to save the entire form state to localStorage whenever a setting changes.
  useEffect(() => {
    const stateToSave = {
        title, text, theme, titleFontFamily, textFontFamily, titleFontSize,
        textFontSize, textAlign, lineSpacing, textPosition, textEffects,
        outlineThickness, outlineColor, outlineStyle, glowColor, glowRadius,
        shadowColor, shadowOffsetX, shadowOffsetY, shadowBlurRadius,
        textBackgroundShape, textBackgroundColor, textBackgroundOpacity,
        imageSize, useAiImageEditing, removeBackground, smartPlacement,
        keepOriginalPhoto, youtubeUrl,
        titleHistory,
        textHistory,
        themeHistory,
    };
    try {
        localStorage.setItem('thumbnailFormState', JSON.stringify(stateToSave));
    } catch (e) {
        console.error("Failed to save form state to localStorage:", e);
    }
  }, [
      title, text, theme, titleFontFamily, textFontFamily, titleFontSize,
      textFontSize, textAlign, lineSpacing, textPosition, textEffects,
      outlineThickness, outlineColor, outlineStyle, glowColor, glowRadius,
      shadowColor, shadowOffsetX, shadowOffsetY, shadowBlurRadius,
      textBackgroundShape, textBackgroundColor, textBackgroundOpacity,
      imageSize, useAiImageEditing, removeBackground, smartPlacement,
      keepOriginalPhoto, youtubeUrl,
      titleHistory,
      textHistory,
      themeHistory,
  ]);
  
  // Effect to close title history dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (titleHistoryRef.current && !titleHistoryRef.current.contains(event.target as Node)) {
            setIsTitleHistoryOpen(false);
        }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
        document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Effect to close text history dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (textHistoryRef.current && !textHistoryRef.current.contains(event.target as Node)) {
            setIsTextHistoryOpen(false);
        }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
        document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Effect to close theme history dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (themeHistoryRef.current && !themeHistoryRef.current.contains(event.target as Node)) {
            setIsThemeHistoryOpen(false);
        }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
        document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Effect to manage rate limit counting
  useEffect(() => {
    const interval = setInterval(() => {
        const now = Date.now();
        const oneMinuteAgo = now - 60 * 1000;
        
        const recentTimestamps = apiCallTimestampsRef.current.filter(
            timestamp => timestamp > oneMinuteAgo
        );
        
        if (recentTimestamps.length !== apiCallTimestampsRef.current.length) {
            apiCallTimestampsRef.current = recentTimestamps;
        }

        if (requestsThisMinute !== recentTimestamps.length) {
            setRequestsThisMinute(recentTimestamps.length);
        }
    }, 1000); // Check every second for better responsiveness

    return () => clearInterval(interval);
  }, [requestsThisMinute]);
  
  const handleImagesSelect = async (files: File[]) => {
    setUploadedImages(prev => [...prev, ...files]);
    const newPreviews = await Promise.all(files.map(fileToBase64));
    setUploadedImagePreviews(prev => [...prev, ...newPreviews]);
  };
  
  const handleImageRemove = (indexToRemove: number) => {
    setUploadedImages(prev => prev.filter((_, index) => index !== indexToRemove));
    setUploadedImagePreviews(prev => prev.filter((_, index) => index !== indexToRemove));
  };

  const handleTextEffectChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setTextEffects(prev => ({
        ...prev,
        [name]: checked,
    }));
  };

  const handleSpellcheck = useCallback(async (
    textToCorrect: string,
    setTextFunction: React.Dispatch<React.SetStateAction<string>>,
    setIsCorrectingFunction: React.Dispatch<React.SetStateAction<boolean>>
  ) => {
    if (!textToCorrect.trim()) return;
  
    const RATE_LIMIT = 60;
    const now = Date.now();
    const oneMinuteAgo = now - 60 * 1000;
    const currentTimestamps = apiCallTimestampsRef.current.filter(ts => ts > oneMinuteAgo);
    
    if (currentTimestamps.length >= RATE_LIMIT) {
        setError(`You have reached your rate limit of ${RATE_LIMIT} requests per minute. Please wait a moment.`);
        return;
    }
  
    apiCallTimestampsRef.current.push(now);
    setRequestsThisMinute(currentTimestamps.length + 1);
  
    setIsCorrectingFunction(true);
    setError(null);
    try {
      const correctedText = await correctSpelling(textToCorrect);
      setTextFunction(correctedText);
    } catch (e: unknown) {
      if (e instanceof Error) {
        setError(e.message);
      } else {
        setError('An unknown error occurred while correcting spelling.');
      }
    } finally {
      setIsCorrectingFunction(false);
    }
  }, []);
  
  const extractYouTubeID = (url: string): string | null => {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  };

  const handleUrlBlur = async () => {
    if (!youtubeUrl.trim()) return;

    const videoId = extractYouTubeID(youtubeUrl);
    if (!videoId) {
      setError("Invalid YouTube URL. Please enter a valid video URL.");
      return;
    }

    setIsFetchingThumbnail(true);
    setError(null);
    
    const thumbnailUrlsToTry = [
      `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`,
      `https://img.youtube.com/vi/${videoId}/sddefault.jpg`,
      `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
    ];

    let thumbnailFetched = false;

    for (const url of thumbnailUrlsToTry) {
        try {
            const response = await fetch(url);
            if (response.ok) {
                const blob = await response.blob();
                // YouTube returns a small placeholder image (~1KB) for non-existent thumbnails.
                // A real thumbnail will be significantly larger.
                if (blob.size < 2000) { 
                    continue; 
                }
                const file = new File([blob], `${videoId}.jpg`, { type: 'image/jpeg' });
                
                // Replace existing images with the fetched one
                setUploadedImages([file]);
                const preview = await fileToBase64(file);
                setUploadedImagePreviews([preview]);
                thumbnailFetched = true;
                break; // Exit loop on success
            }
        } catch (err) {
            console.error(`Error fetching thumbnail from ${url}:`, err);
        }
    }

    if (!thumbnailFetched) {
      setError("Could not fetch a high-quality thumbnail from the URL. The video may be private, deleted, or has no available thumbnail.");
    }
    
    setIsFetchingThumbnail(false);
  };

  const handleGenerate = useCallback(async () => {
    setError(null);
    setIsLoading(true);
    setGeneratedImages(null);
    
    const RATE_LIMIT = 60;
    const now = Date.now();
    const oneMinuteAgo = now - 60 * 1000;
    
    // Clean up old timestamps before check
    apiCallTimestampsRef.current = apiCallTimestampsRef.current.filter(
        timestamp => timestamp > oneMinuteAgo
    );
    const currentRequestCount = apiCallTimestampsRef.current.length;

    const generateFromScratch = uploadedImages.length === 0;
    let apiCallsToMake = 0;
    if (useAiImageEditing) {
        apiCallsToMake = generateFromScratch ? 4 : uploadedImages.length * 4;
    }

    if (currentRequestCount + apiCallsToMake > RATE_LIMIT) {
        setError(`This action requires ${apiCallsToMake} API call(s), but you only have ${RATE_LIMIT - currentRequestCount} left in the current minute. Please wait a moment for your quota to reset.`);
        setIsLoading(false);
        return;
    }

    if (title.trim()) {
        const newHistory = [title.trim(), ...titleHistory.filter(t => t.toLowerCase() !== title.trim().toLowerCase())];
        setTitleHistory(newHistory.slice(0, 3));
    }

    if (text.trim()) {
        const newTextHistory = [text.trim(), ...textHistory.filter(t => t.toLowerCase() !== text.trim().toLowerCase())];
        setTextHistory(newTextHistory.slice(0, 3));
    }

    if (theme.trim()) {
        const newThemeHistory = [theme.trim(), ...themeHistory.filter(t => t.toLowerCase() !== theme.trim().toLowerCase())];
        setThemeHistory(newThemeHistory.slice(0, 3));
    }

    if (apiCallsToMake > 0) {
        const newTimestamps = Array(apiCallsToMake).fill(now);
        apiCallTimestampsRef.current.push(...newTimestamps);
        setRequestsThisMinute(apiCallTimestampsRef.current.length);
    }

    const clientSideOptions = {
        title,
        text,
        imageSize,
        titleFontFamily,
        textFontFamily,
        titleFontSize,
        textFontSize,
        textAlign,
        lineSpacing,
        textPosition,
        textEffects,
        outlineThickness,
        outlineColor,
        outlineStyle,
        glowColor,
        glowRadius,
        shadowColor,
        shadowOffsetX,
        shadowOffsetY,
        shadowBlurRadius,
        textBackgroundShape,
        textBackgroundColor,
        textBackgroundOpacity,
    };
    
    const historyOptions = {
      ...clientSideOptions,
      theme,
      useAiImageEditing,
      removeBackground,
      smartPlacement,
      keepOriginalPhoto,
    };

    try {
        if (useAiImageEditing) {
            const textEffectPrompt = getTextEffectsPrompt(
              textEffects, outlineThickness, outlineColor, outlineStyle,
              glowColor, glowRadius, shadowColor
            );
            
            let textBackgroundInstruction = '';
            if (textBackgroundShape !== 'none') {
                textBackgroundInstruction = `Place all text on a ${textBackgroundShape} background to maximize readability. This background shape MUST have a color of ${textBackgroundColor} and an opacity of approximately ${textBackgroundOpacity}.`;
            } else {
                textBackgroundInstruction = 'The text should be placed directly on the image. Do NOT add any background shapes behind the text.';
            }

            const titleFontPrompt = titleFontFamily === 'default' 
                ? 'Choose a font that best fits the theme for the title.' 
                : `For the title text, use ${getFontDescription(titleFontFamily)}.`;

            const textFontPrompt = textFontFamily === 'default' 
                ? 'Choose a readable, complementary font for the secondary text.' 
                : `For the secondary text, use ${getFontDescription(textFontFamily)}.`;

            const aspectRatio = getAspectRatio(imageSize);

            const commonPromptSegment = `
**Design Principles to Follow:**
1.  **Readability is King:** ${textEffectPrompt} ${textBackgroundInstruction} Use high-contrast colors for the text itself.
2.  **Font Style:** ${titleFontPrompt} ${textFontPrompt}
3.  **Font Size:** The title text MUST have an ${titleFontSize.replace('_', ' ')} font size. The secondary text MUST have a ${textFontSize.replace('_', ' ')} font size.
4.  **Text Layout:** The title text MUST be ${textAlign} aligned. Use ${lineSpacing} line spacing for all text.
5.  **Emotional Impact:** The final image should evoke curiosity, excitement, or another strong emotion relevant to the theme. Use color grading and dynamic lighting to enhance the mood.
6.  **Composition:** Apply principles like the rule of thirds. The main subject and text should be the clear focal points. Avoid clutter.
7.  **Branding & Style:** The final design should look professional and polished, consistent with top-tier YouTube creators.

**What to Avoid:**
- Do not add any new graphical elements (like emojis, icons, or clipart) unless explicitly requested in the theme.
- Ensure text does not obscure the most important parts of the image.

**Final Output:**
- Return only the edited image.
- Strictly adhere to the ${aspectRatio} aspect ratio.`;

            let backgroundInstruction = '';
            if (removeBackground && uploadedImages.length > 0 && !keepOriginalPhoto) {
                backgroundInstruction = `
        **Background Modification:**
        - **Action:** Remove the original background from the image completely.
        - **Replacement:** Replace it with a new background that perfectly matches the **Visual Theme** ("${theme}"). The subject(s) from the original image should be seamlessly integrated into this new background.`;
            }

            let smartPlacementInstruction = '';
            if (smartPlacement.trim()) {
                smartPlacementInstruction = `
        **Smart Text Placement:**
        - **Instruction:** Follow this specific instruction for text placement: "${smartPlacement}".
        - **Interaction:** The text must interact with the image's subjects as described. This is a critical instruction.`;
            }

            let keepPhotoInstruction = '';
            if (keepOriginalPhoto && uploadedImages.length > 0) {
                keepPhotoInstruction = `
**CRITICAL IMAGE CONSTRAINT:**
- **DO NOT CHANGE THE IMAGE:** You absolutely MUST NOT alter, edit, filter, color grade, or change the content of the provided base image in any way. This instruction overrides any other instructions about mood, color, or lighting for the image itself.
- **YOUR ONLY TASK:** Add the specified text ("${title}" and "${text}") on top of the original, untouched image. Follow all styling and placement rules for the TEXT, but the original photo MUST remain perfectly intact underneath.`;
            }

            const editPrompt = `You are an expert YouTube thumbnail designer. Your task is to transform the provided image into a viral, high-CTR (Click-Through Rate) YouTube thumbnail.

**Core Request:**
- **Goal:** Create a visually arresting thumbnail by editing the provided base image.
- **Output Aspect Ratio:** The final image MUST have a ${aspectRatio}.
- **Title:** "${title}" (This is the hero text. Make it bold, impactful, and instantly readable).
- **Secondary Text:** "${text}" (Use this to add context or create intrigue. It should be smaller than the title and placed in the ${textPosition.replace(/-/g, ' ')} area of the image).
- **Visual Theme:** "${theme}" (This dictates the mood. Examples: vibrant & energetic, dark & mysterious, clean & minimalist).
${keepPhotoInstruction}
${backgroundInstruction}
${smartPlacementInstruction}
${commonPromptSegment}`;
            
            const createPrompt = `You are an expert YouTube thumbnail designer. Your task is to generate a viral, high-CTR (Click-Through Rate) YouTube thumbnail from scratch based on the user's text inputs.

**Core Request:**
- **Goal:** Create a visually arresting thumbnail FROM SCRATCH.
- **Output Aspect Ratio:** The final image MUST have a ${aspectRatio}.
- **Title:** "${title}" (This is the hero text. Make it bold, impactful, and instantly readable).
- **Secondary Text:** "${text}" (Use this to add context or create intrigue. It should be smaller than the title and placed in the ${textPosition.replace(/-/g, ' ')} area of the image).
- **Visual Theme & Subject:** "${theme}" (This is the most important part. Generate a background image and overall style based on this. Examples: a vibrant gaming scene, a dark mysterious forest, a clean minimalist background with code).
${smartPlacementInstruction}
${commonPromptSegment}`;
            
            const prompt = generateFromScratch ? createPrompt : editPrompt;
            
            if (generateFromScratch) {
                const thumbnails = await generateThumbnail(prompt);
                const results: GeneratedImageGroup[] = [{ thumbnails }];
                setGeneratedImages(results);
                 const newHistory = await historyService.saveGenerationToHistory({ ...historyOptions, generatedImages: thumbnails });
                 setHistory(newHistory);
            } else {
                const generationPromises = uploadedImages.map(async (imageFile) => {
                    const base64Image = await fileToBase64(imageFile);
                    const thumbnails = await generateThumbnail(prompt, base64Image);
                    return { baseImage: base64Image, thumbnails };
                });
                const promiseResults = await Promise.all(generationPromises);
                setGeneratedImages(promiseResults);
                if (promiseResults.length > 0) {
                    const firstSuccess = promiseResults[0];
                    const newHistory = await historyService.saveGenerationToHistory({ ...historyOptions, baseImage: firstSuccess.baseImage, generatedImages: firstSuccess.thumbnails });
                    setHistory(newHistory);
                }
            }
        } else { // Client-side generation
            if (generateFromScratch) {
                 const thumbnails = await generateClientSideThumbnails(clientSideOptions);
                 const results: GeneratedImageGroup[] = [{ thumbnails }];
                 setGeneratedImages(results);
                 const newHistory = await historyService.saveGenerationToHistory({ ...historyOptions, generatedImages: thumbnails });
                 setHistory(newHistory);
            } else {
                const generationPromises = uploadedImages.map(async (imageFile) => {
                    const base64Image = await fileToBase64(imageFile);
                    const thumbnails = await generateClientSideThumbnails({ ...clientSideOptions, baseImage: base64Image });
                    return { baseImage: base64Image, thumbnails };
                });
                const promiseResults = await Promise.all(generationPromises);
                setGeneratedImages(promiseResults);
                 if (promiseResults.length > 0) {
                    const firstSuccess = promiseResults[0];
                    const newHistory = await historyService.saveGenerationToHistory({ ...historyOptions, baseImage: firstSuccess.baseImage, generatedImages: firstSuccess.thumbnails });
                    setHistory(newHistory);
                }
            }
        }

        setTimeout(() => {
            resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 100);
      
    } catch (e: unknown) {
      if (e instanceof Error) {
        setError(e.message);
      } else {
        setError('An unexpected error occurred during generation setup.');
      }
    } finally {
      setIsLoading(false);
    }
  }, [uploadedImages, title, text, theme, imageSize, useAiImageEditing, titleFontFamily, textFontFamily, titleFontSize, textFontSize, textEffects, outlineThickness, outlineColor, outlineStyle, glowColor, glowRadius, shadowColor, shadowOffsetX, shadowOffsetY, shadowBlurRadius, textAlign, lineSpacing, textPosition, textBackgroundShape, textBackgroundColor, textBackgroundOpacity, removeBackground, smartPlacement, keepOriginalPhoto, titleHistory, textHistory, themeHistory]);
  
  const handleDownloadSelectedImage = useCallback(() => {
    if (!selectedImage) return;
    const link = document.createElement('a');
    link.href = selectedImage.url;
    link.download = selectedImage.fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }, [selectedImage]);
  
  const handleLoadFromHistory = (item: HistoryEntry) => {
    setTitle(item.title);
    setText(item.text);
    setTheme(item.theme);
    setImageSize(item.imageSize || '1280x720');
    setUseAiImageEditing(item.useAiImageEditing ?? true); // Default to true for old entries
    setRemoveBackground(item.removeBackground || false);
    setSmartPlacement(item.smartPlacement || '');
    setKeepOriginalPhoto(item.keepOriginalPhoto || false);

    setTitleFontFamily(item.titleFontFamily || item.fontFamily || 'impact');
    setTextFontFamily(item.textFontFamily || item.fontFamily || 'roboto');
    setTitleFontSize(item.titleFontSize || item.fontSize || 'extra_large');
    setTextFontSize(item.textFontSize || item.fontSize || 'medium');

    setTextAlign(item.textAlign || 'center');
    setLineSpacing(item.lineSpacing || 'normal');
    
    // Backwards compatibility for old position values
    const legacyPositionMap: { [key: string]: string } = {
        top: 'top-center',
        bottom: 'bottom-center',
        left: 'middle-left',
        right: 'middle-right',
    };
    const newPosition = item.textPosition && legacyPositionMap[item.textPosition] 
        ? legacyPositionMap[item.textPosition] 
        : item.textPosition || 'bottom-center';
    setTextPosition(newPosition);
    
    if (item.textEffects) {
        setTextEffects(item.textEffects);
    } else if (item.textEffect) {
        const legacyEffects = { outline: false, glow: false, drop_shadow: false };
        if (item.textEffect === 'outline') legacyEffects.outline = true;
        if (item.textEffect === 'glow') legacyEffects.glow = true;
        if (item.textEffect === 'drop_shadow') legacyEffects.drop_shadow = true;
        setTextEffects(legacyEffects);
    } else {
        setTextEffects({ outline: true, glow: false, drop_shadow: false });
    }

    setOutlineThickness(item.outlineThickness || 'medium');
    setOutlineColor(item.outlineColor || 'black');
    setOutlineStyle(item.outlineStyle || 'solid');
    setGlowColor(item.glowColor || 'yellow');
    setGlowRadius(item.glowRadius || 'normal');
    setShadowColor(item.shadowColor || 'black');
    setShadowOffsetX(item.shadowOffsetX || '4px');
    setShadowOffsetY(item.shadowOffsetY || '4px');
    setShadowBlurRadius(item.shadowBlurRadius || '6px');
    
    setTextBackgroundShape(item.textBackgroundShape || 'none');
    setTextBackgroundColor(item.textBackgroundColor || 'black');
    setTextBackgroundOpacity(item.textBackgroundOpacity || '75%');

    if (item.baseImage) {
      setGeneratedImages([{ baseImage: item.baseImage, thumbnails: item.generatedImages }]);
      const imageFile = dataURLtoFile(item.baseImage, `history-image-${item.id}.png`);
      setUploadedImages([imageFile]);
      setUploadedImagePreviews([item.baseImage]);
    } else {
      setGeneratedImages([{ thumbnails: item.generatedImages }]);
      setUploadedImages([]);
      setUploadedImagePreviews([]);
    }
    
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDeleteHistoryItem = (id: number) => {
    const updatedHistory = historyService.removeHistoryItem(id);
    setHistory(updatedHistory);
  };

  const handleClearHistory = () => {
    if (window.confirm('Are you sure you want to clear all generation history? This cannot be undone.')) {
        const updatedHistory = historyService.clearHistory();
        setHistory(updatedHistory);
    }
  };

  const handleHistoryImageClick = (imageUrl: string, filename: string) => {
    setSelectedImage({ url: imageUrl, fileName: filename });
  };
  
  const isFormIncomplete = !title || !text || (useAiImageEditing && !theme) || 
    (textEffects.outline && !outlineColor) ||
    (textEffects.glow && !glowColor) ||
    (textEffects.drop_shadow && !shadowColor) ||
    (textBackgroundShape !== 'none' && !textBackgroundColor);

  const getButtonText = () => {
    if (isLoading) return 'Generating...';
    if (uploadedImages.length > 1) {
        const total = uploadedImages.length * 4;
        return `Generate for ${uploadedImages.length} Images (${total} total)`;
    }
    return 'Generate 4 Thumbnails';
  };
  
  const RATE_LIMIT = 60;
  const requestsLeft = Math.max(0, RATE_LIMIT - requestsThisMinute);

  const apiCallsPerGeneration = useAiImageEditing 
    ? (uploadedImages.length === 0 ? 4 : uploadedImages.length * 4) 
    : 0;
  
  const generationsLeft = apiCallsPerGeneration > 0 
    ? Math.floor(requestsLeft / apiCallsPerGeneration) 
    : Infinity;


  return (
    <>
      {selectedImage && (
        <ImageModal
          imageUrl={selectedImage.url}
          onClose={() => setSelectedImage(null)}
          onDownload={handleDownloadSelectedImage}
        />
      )}
      <div className="min-h-screen text-white font-sans flex flex-col items-center p-4 sm:p-8">
        <Header />
        <main className="w-full max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-gray-800/50 backdrop-blur-sm p-6 sm:p-8 rounded-2xl shadow-2xl border border-gray-700">
            <div className="space-y-6">
              <div ref={titleHistoryRef} className="relative">
                <label htmlFor="title" className="block mb-2 text-sm font-medium text-gray-300">
                  Thumbnail Title
                </label>
                <div className="relative">
                   <button
                    type="button"
                    onClick={() => setIsTitleHistoryOpen(prev => !prev)}
                    disabled={titleHistory.length === 0}
                    className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400 hover:text-blue-400 disabled:text-gray-600 disabled:cursor-not-allowed transition-colors"
                    title="View saved titles"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M9.568 3H5.25A2.25 2.25 0 003 5.25v4.318c0 .597.237 1.17.659 1.591l6.472 6.472a2.25 2.25 0 003.182 0l4.318-4.318a2.25 2.25 0 000-3.182L11.16 3.66A2.25 2.25 0 009.568 3z" />
                        <path strokeLinecap="round" strokeLinejoin="round" d="M6 6h.008v.008H6V6z" />
                    </svg>
                  </button>
                  <input
                    type="text"
                    id="title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g., My Epic Adventure"
                    className="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 pl-10 pr-10 transition duration-300"
                  />
                  <button
                    type="button"
                    onClick={() => handleSpellcheck(title, setTitle, setIsCorrectingSpelling)}
                    disabled={!title || isCorrectingSpelling}
                    className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-blue-400 disabled:text-gray-600 disabled:cursor-not-allowed transition-colors"
                    title="Correct Spelling with AI"
                  >
                    {isCorrectingSpelling ? (
                      <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                    ) : (
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M5 3v4M3 5h4M9 17v4m-2-2h4m-4-6l-3 3m0 0l3 3m-3-3h12m6-4v4m-2-2h4" />
                      </svg>
                    )}
                  </button>
                </div>
                 {isTitleHistoryOpen && titleHistory.length > 0 && (
                    <ul className="absolute z-20 w-full mt-1 bg-gray-700 border border-gray-600 rounded-lg shadow-lg max-h-40 overflow-y-auto">
                        {titleHistory.map((item, index) => (
                            <li
                                key={index}
                                onClick={() => {
                                    setTitle(item);
                                    setIsTitleHistoryOpen(false);
                                }}
                                className="px-3 py-2 text-sm text-gray-200 cursor-pointer hover:bg-blue-600/50"
                            >
                                {item}
                            </li>
                        ))}
                    </ul>
                )}
              </div>
              <div ref={textHistoryRef} className="relative">
                <label htmlFor="text" className="block mb-2 text-sm font-medium text-gray-300">
                  Thumbnail Text
                </label>
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setIsTextHistoryOpen(prev => !prev)}
                    disabled={textHistory.length === 0}
                    className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400 hover:text-blue-400 disabled:text-gray-600 disabled:cursor-not-allowed transition-colors"
                    title="View saved texts"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25H12" />
                    </svg>
                  </button>
                  <input
                    type="text"
                    id="text"
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    placeholder="e.g., You Won't Believe This!"
                    className="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 pl-10 pr-10 transition duration-300"
                  />
                  <button
                    type="button"
                    onClick={() => handleSpellcheck(text, setText, setIsCorrectingTextSpelling)}
                    disabled={!text || isCorrectingTextSpelling}
                    className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-blue-400 disabled:text-gray-600 disabled:cursor-not-allowed transition-colors"
                    title="Correct Spelling with AI"
                  >
                    {isCorrectingTextSpelling ? (
                      <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                    ) : (
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M5 3v4M3 5h4M9 17v4m-2-2h4m-4-6l-3 3m0 0l3 3m-3-3h12m6-4v4m-2-2h4" />
                      </svg>
                    )}
                  </button>
                </div>
                 {isTextHistoryOpen && textHistory.length > 0 && (
                    <ul className="absolute z-20 w-full mt-1 bg-gray-700 border border-gray-600 rounded-lg shadow-lg max-h-40 overflow-y-auto">
                        {textHistory.map((item, index) => (
                            <li
                                key={index}
                                onClick={() => {
                                    setText(item);
                                    setIsTextHistoryOpen(false);
                                }}
                                className="px-3 py-2 text-sm text-gray-200 cursor-pointer hover:bg-blue-600/50"
                            >
                                {item}
                            </li>
                        ))}
                    </ul>
                )}
              </div>
              <div ref={themeHistoryRef} className="relative">
                <label htmlFor="theme" className="block mb-2 text-sm font-medium text-gray-300">
                    Thumbnail Theme / Style
                </label>
                <div className="relative">
                    <button
                        type="button"
                        onClick={() => setIsThemeHistoryOpen(prev => !prev)}
                        disabled={themeHistory.length === 0 || !useAiImageEditing}
                        className="absolute top-2.5 left-0 flex items-center pl-3 text-gray-400 hover:text-blue-400 disabled:text-gray-600 disabled:cursor-not-allowed transition-colors"
                        title="View saved themes"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456zM16.898 20.562L16.25 21.75l-.648-1.188a2.25 2.25 0 01-1.47-1.47l-1.188-.648 1.188-.648a2.25 2.25 0 011.47-1.47l.648-1.188.648 1.188a2.25 2.25 0 011.47 1.47l1.188.648-1.188.648a2.25 2.25 0 01-1.47 1.47z" />
                        </svg>
                    </button>
                    <textarea
                        id="theme"
                        value={theme}
                        onChange={(e) => setTheme(e.target.value)}
                        placeholder="e.g., Vibrant, cinematic, minimalist"
                        rows={3}
                        className="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 pl-10 pr-10 transition duration-300 resize-y"
                        disabled={!useAiImageEditing}
                    />
                    <button
                        type="button"
                        onClick={() => handleSpellcheck(theme, setTheme, setIsCorrectingThemeSpelling)}
                        disabled={!theme || isCorrectingThemeSpelling || !useAiImageEditing}
                        className="absolute top-2.5 right-0 flex items-center pr-3 text-gray-400 hover:text-blue-400 disabled:text-gray-600 disabled:cursor-not-allowed transition-colors"
                        title="Correct Spelling with AI"
                    >
                        {isCorrectingThemeSpelling ? (
                            <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                        ) : (
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M5 3v4M3 5h4M9 17v4m-2-2h4m-4-6l-3 3m0 0l3 3m-3-3h12m6-4v4m-2-2h4" />
                            </svg>
                        )}
                    </button>
                </div>
                 {isThemeHistoryOpen && themeHistory.length > 0 && (
                    <ul className="absolute z-20 w-full mt-1 bg-gray-700 border border-gray-600 rounded-lg shadow-lg max-h-40 overflow-y-auto">
                        {themeHistory.map((item, index) => (
                            <li
                                key={index}
                                onClick={() => {
                                    setTheme(item);
                                    setIsThemeHistoryOpen(false);
                                }}
                                className="px-3 py-2 text-sm text-gray-200 cursor-pointer hover:bg-blue-600/50"
                            >
                                {item}
                            </li>
                        ))}
                    </ul>
                )}
                {!useAiImageEditing && (
                  <div className="absolute inset-0 flex items-center justify-center bg-gray-700/50 rounded-lg top-7">
                    <span className="text-sm text-gray-400">Theme is only available for AI editing.</span>
                  </div>
                )}
              </div>
              
              <div className="pt-2 border-t border-gray-700/50">
                <h3 className="text-lg font-semibold text-gray-200 mb-4">Text Styling</h3>
                <div className="space-y-4">
                    
                    <div className="space-y-4 bg-gray-700/30 p-4 rounded-lg">
                      <h4 className="text-sm font-semibold text-gray-300">Title Font & Size</h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <FontSelect id="titleFontFamily" label="Font Family" value={titleFontFamily} onChange={setTitleFontFamily} options={fontOptions} />
                        <SelectInput id="titleFontSize" label="Font Size" value={titleFontSize} onChange={e => setTitleFontSize(e.target.value)} options={fontSizeOptions} />
                      </div>
                    </div>
                    
                    <div className="space-y-4 bg-gray-700/30 p-4 rounded-lg">
                      <h4 className="text-sm font-semibold text-gray-300">Secondary Text Font, Size & Position</h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <FontSelect id="textFontFamily" label="Font Family" value={textFontFamily} onChange={setTextFontFamily} options={fontOptions} />
                        <SelectInput id="textFontSize" label="Font Size" value={textFontSize} onChange={e => setTextFontSize(e.target.value)} options={fontSizeOptions} />
                      </div>
                      <SelectInput id="textPosition" label="Position" value={textPosition} onChange={e => setTextPosition(e.target.value)} options={textPositionOptions} />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <SelectInput id="textAlign" label="Title Alignment" value={textAlign} onChange={e => setTextAlign(e.target.value)} options={textAlignOptions} />
                      <SelectInput id="lineSpacing" label="Line Spacing" value={lineSpacing} onChange={e => setLineSpacing(e.target.value)} options={lineSpacingOptions} />
                    </div>
                    
                    <div className="pt-2 border-t border-gray-700/50 mt-4">
                      <h3 className="text-sm font-semibold text-gray-300 my-4">Smart Text Placement</h3>
                       <TextInput
                          id="smartPlacement"
                          label="Placement Instructions (AI Only)"
                          value={smartPlacement}
                          onChange={(e) => setSmartPlacement(e.target.value)}
                          placeholder="e.g., wrap text around the person's head"
                          disabled={!useAiImageEditing}
                        />
                    </div>

                    <div className="pt-2 border-t border-gray-700/50 mt-4">
                      <h3 className="text-sm font-semibold text-gray-300 my-4">Text Background</h3>
                      <SelectInput
                          id="textBackgroundShape"
                          label="Background Shape"
                          value={textBackgroundShape}
                          onChange={e => setTextBackgroundShape(e.target.value)}
                          options={backgroundShapeOptions}
                      />
                      {textBackgroundShape !== 'none' && (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-gray-700/30 p-4 rounded-lg mt-4">
                              <SelectInput
                                  id="textBackgroundColor"
                                  label="Shape Color"
                                  value={textBackgroundColor}
                                  onChange={e => setTextBackgroundColor(e.target.value)}
                                  options={backgroundColorOptions}
                              />
                              <SelectInput
                                  id="textBackgroundOpacity"
                                  label="Shape Opacity"
                                  value={textBackgroundOpacity}
                                  onChange={e => setTextBackgroundOpacity(e.target.value)}
                                  options={backgroundOpacityOptions}
                              />
                          </div>
                      )}
                    </div>

                    <div className="pt-2 border-t border-gray-700/50 mt-4">
                       <h3 className="text-sm font-semibold text-gray-300 my-4">Text Effects</h3>
                      <div className="flex items-center space-x-6">
                        <CheckboxInput id="outline" name="outline" label="Outline" checked={textEffects.outline} onChange={handleTextEffectChange} />
                        <CheckboxInput id="glow" name="glow" label="Glow" checked={textEffects.glow} onChange={handleTextEffectChange} />
                        <CheckboxInput id="drop_shadow" name="drop_shadow" label="Drop Shadow" checked={textEffects.drop_shadow} onChange={handleTextEffectChange} />
                      </div>
                    </div>

                    {textEffects.outline && (
                      <div className="bg-gray-700/30 p-4 rounded-lg space-y-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <SelectInput id="outlineThickness" label="Outline Thickness" value={outlineThickness} onChange={e => setOutlineThickness(e.target.value)} options={outlineThicknessOptions} />
                          <SelectInput id="outlineStyle" label="Outline Style" value={outlineStyle} onChange={e => setOutlineStyle(e.target.value)} options={outlineStyleOptions} />
                        </div>
                        <SelectInput id="outlineColor" label="Outline Color" value={outlineColor} onChange={e => setOutlineColor(e.target.value)} options={outlineColorOptions} />
                      </div>
                    )}

                    {textEffects.glow && (
                       <div className="bg-gray-700/30 p-4 rounded-lg space-y-4">
                          <SelectInput id="glowColor" label="Glow Color" value={glowColor} onChange={e => setGlowColor(e.target.value)} options={glowColorOptions} />
                          <SelectInput id="glowRadius" label="Glow Radius" value={glowRadius} onChange={e => setGlowRadius(e.target.value)} options={glowRadiusOptions} />
                       </div>
                    )}
                    
                    {textEffects.drop_shadow && (
                       <div className="bg-gray-700/30 p-4 rounded-lg space-y-4">
                          <SelectInput id="shadowColor" label="Shadow Color" value={shadowColor} onChange={e => setShadowColor(e.target.value)} options={shadowColorOptions} />
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                             <SelectInput id="shadowOffsetX" label="Shadow X Offset" value={shadowOffsetX} onChange={e => setShadowOffsetX(e.target.value)} options={shadowOffsetOptions} />
                             <SelectInput id="shadowOffsetY" label="Shadow Y Offset" value={shadowOffsetY} onChange={e => setShadowOffsetY(e.target.value)} options={shadowOffsetOptions} />
                          </div>
                          <SelectInput id="shadowBlurRadius" label="Shadow Blur Radius" value={shadowBlurRadius} onChange={e => setShadowBlurRadius(e.target.value)} options={shadowBlurOptions} />
                       </div>
                    )}
                </div>
              </div>
              
              <div className="pt-2 border-t border-gray-700/50">
                  <h3 className="text-lg font-semibold text-gray-200 my-4">Image Settings</h3>
                  <div className="space-y-4">
                      <ToggleSwitch
                        id="ai-toggle"
                        label="Use AI Image Editing"
                        enabled={useAiImageEditing}
                        onChange={setUseAiImageEditing}
                        helpText="ON: AI edits/creates the image based on your theme. OFF: Text is overlaid directly."
                      />
                      <ToggleSwitch
                        id="keep-original-photo-toggle"
                        label="Keep Original Photo (AI Text Only)"
                        enabled={keepOriginalPhoto}
                        onChange={setKeepOriginalPhoto}
                        helpText="Instructs the AI to only add text and effects, without altering the base image."
                        disabled={!useAiImageEditing || uploadedImages.length === 0}
                      />
                      <ToggleSwitch
                        id="background-removal-toggle"
                        label="Remove Background (AI Only)"
                        enabled={removeBackground}
                        onChange={setRemoveBackground}
                        helpText="Removes the background and replaces it based on the theme."
                        disabled={!useAiImageEditing || uploadedImages.length === 0 || keepOriginalPhoto}
                      />
                      <SelectInput id="imageSize" label="Output Image Size" value={imageSize} onChange={e => setImageSize(e.target.value)} options={imageSizeOptions} />
                       <div className="relative">
                          <label htmlFor="youtubeUrl" className="block mb-2 text-sm font-medium text-gray-300">Fetch Thumbnail from YouTube URL</label>
                          <div className="relative">
                              <input
                                  type="text"
                                  id="youtubeUrl"
                                  value={youtubeUrl}
                                  onChange={(e) => setYoutubeUrl(e.target.value)}
                                  onBlur={handleUrlBlur}
                                  placeholder="Paste a YouTube video link here"
                                  disabled={isFetchingThumbnail}
                                  className="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 transition duration-300 pr-10"
                              />
                              {isFetchingThumbnail && (
                                  <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                                      <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                      </svg>
                                  </div>
                              )}
                          </div>
                      </div>

                      <div className="relative flex items-center justify-center my-2">
                          <div className="absolute inset-0 flex items-center" aria-hidden="true">
                              <div className="w-full border-t border-gray-600"></div>
                          </div>
                          <div className="relative bg-gray-800/50 px-3 text-sm text-gray-400">OR</div>
                      </div>

                      <ImageInput 
                        onImagesSelect={handleImagesSelect} 
                        onImageRemove={handleImageRemove}
                        uploadedFiles={uploadedImages}
                        previews={uploadedImagePreviews}
                      />
                  </div>
              </div>

              {error && (
                <div className="bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-lg relative flex items-start space-x-3" role="alert">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 flex-shrink-0 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <div className="whitespace-pre-wrap">
                    <strong className="font-bold block">An error occurred</strong>
                    <span className="block sm:inline text-red-400">{error}</span>
                  </div>
                </div>
              )}
              <div className="pt-4 space-y-4">
                 <QuotaStatus generationsLeft={generationsLeft} />
                <Button onClick={handleGenerate} isLoading={isLoading} disabled={isFormIncomplete}>
                  {getButtonText()}
                </Button>
              </div>
            </div>
          </div>
          <div ref={resultsRef} className="bg-gray-800/50 backdrop-blur-sm p-4 rounded-2xl shadow-2xl border border-gray-700 max-h-[calc(100vh-10rem)] overflow-y-auto">
            {isLoading ? (
              <div className="w-full grid grid-cols-1 gap-4">
                {Array.from({ length: 4 }).map((_, index) => (
                  <SkeletonLoader key={index} />
                ))}
              </div>
            ) : generatedImages && generatedImages.length > 0 ? (
              <div className="w-full space-y-8">
                {generatedImages.map((group, groupIndex) => (
                  <div key={groupIndex}>
                      {group.baseImage ? (
                        <div className="flex items-center gap-4 mb-4">
                            <img src={group.baseImage} alt={`Base image ${groupIndex + 1}`} className="w-24 h-auto rounded-md border-2 border-gray-600 bg-gray-900/50 transition-transform duration-300 ease-in-out hover:scale-[2.5] hover:z-10 origin-left cursor-pointer" />
                            <h3 className="text-xl font-bold text-gray-200">Results for Base Image {groupIndex + 1}</h3>
                        </div>
                      ) : (
                        <h3 className="text-xl font-bold text-gray-200 mb-4">Generated Results</h3>
                      )}
                      <div className="grid grid-cols-1 gap-4">
                      {group.thumbnails.map((img, thumbIndex) => (
                          <div 
                              key={thumbIndex} 
                              className="relative group rounded-lg overflow-hidden bg-gray-900/50 aspect-video cursor-pointer"
                              onClick={() => setSelectedImage({ url: img, fileName: `thumbnail-base${groupIndex + 1}-var${thumbIndex + 1}.png` })}
                              aria-label={`Enlarge thumbnail ${thumbIndex + 1} for base image ${groupIndex + 1}`}
                          >
                          <img src={img} alt={`Generated Thumbnail ${groupIndex + 1}-${thumbIndex + 1}`} className="w-full h-full object-contain transition-transform duration-300 ease-in-out group-hover:scale-110" />
                          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-60 transition-all duration-300 flex items-center justify-center">
                              <div 
                                  className="text-white p-3 rounded-full bg-blue-600/80 opacity-0 group-hover:opacity-100 transform scale-90 group-hover:scale-100 transition-all duration-300"
                                  aria-hidden="true"
                              >
                                  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                      <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v6m3-3h-6" />
                                  </svg>
                              </div>
                          </div>
                          </div>
                      ))}
                      </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="w-full h-full min-h-[400px] bg-gray-900/50 rounded-lg flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <p className="text-lg font-semibold">Generated thumbnails will appear here.</p>
                  <p>Fill out the form and click Generate!</p>
                </div>
              </div>
            )}
          </div>
        </main>
        <HistoryPanel
          isLoading={isHistoryLoading}
          history={history}
          onLoad={handleLoadFromHistory}
          onDelete={handleDeleteHistoryItem}
          onClear={handleClearHistory}
          onImageClick={handleHistoryImageClick}
        />
      </div>
    </>
  );
};

export default App;
