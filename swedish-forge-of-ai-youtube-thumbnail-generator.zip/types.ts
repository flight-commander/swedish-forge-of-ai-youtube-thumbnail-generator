
// FIX: Add missing type definitions for AspectRatio, ThumbnailStyle, and GenerateThumbnailParams.
export enum AspectRatio {
  SixteenNine = '16:9',
  FourThree = '4:3',
  OneOne = '1:1',
  NineSixteen = '9:16',
}

export enum ThumbnailStyle {
  Photorealistic = 'photorealistic',
  DigitalArt = 'digital-art',
  Cartoon = 'cartoon',
  Minimalist = 'minimalist',
  Cinematic = 'cinematic',
  Vibrant = 'vibrant-illustration',
  Vintage = 'vintage',
}

export interface GenerateThumbnailParams {
    videoUrl: string;
    title: string;
    text: string;
    theme: string | ThumbnailStyle;
    gender: string;
    withBanner: boolean;
    aspectRatio?: AspectRatio;
}


export interface HistoryEntry {
  id: number; // Using timestamp for simplicity
  title: string;
  text: string;
  theme: string;
  imageSize?: string;
  useAiImageEditing?: boolean;
  removeBackground?: boolean;
  smartPlacement?: string;
  keepOriginalPhoto?: boolean;
  
  // Legacy font properties
  fontFamily?: string;
  fontSize?: string;

  // New font properties
  titleFontFamily?: string;
  textFontFamily?: string;
  titleFontSize?: string;
  textFontSize?: string;
  
  textEffect?: string; // Keep for legacy compatibility
  textEffects: {
    outline: boolean;
    glow: boolean;
    drop_shadow: boolean;
  };
  outlineThickness?: string;
  outlineColor?: string;
  outlineStyle?: string;
  glowColor?: string;
  glowRadius?: string;
  shadowColor?: string;
  shadowOffsetX?: string;
  shadowOffsetY?: string;
  shadowBlurRadius?: string;
  textAlign?: string;
  lineSpacing?: string;
  textPosition?: string;
  textBackgroundShape?: string;
  textBackgroundColor?: string;
  textBackgroundOpacity?: string;
  baseImage?: string; // Stored as base64, optional for generated images
  generatedImages: string[]; // Stored as base64
}
