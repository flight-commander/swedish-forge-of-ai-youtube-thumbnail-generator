export interface GenerateThumbnailParams {
  videoUrl: string;
  title: string;
  text: string;
  theme: string;
  gender: string;
}

export interface Part {
    text?: string;
    inlineData?: {
      mimeType: string;
      data: string;
    };
}