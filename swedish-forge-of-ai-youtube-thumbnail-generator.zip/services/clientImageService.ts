interface ClientSideGenerationOptions {
    baseImage?: string;
    title: string;
    text: string;
    imageSize: string;
    titleFontFamily: string;
    textFontFamily: string;
    titleFontSize: string;
    textFontSize: string;
    textAlign: string;
    lineSpacing: string;
    textPosition: string;
    textEffects: {
        outline: boolean;
        glow: boolean;
        drop_shadow: boolean;
    };
    outlineThickness: string;
    outlineColor: string;
    outlineStyle: string;
    glowColor: string;
    glowRadius: string;
    shadowColor: string;
    shadowOffsetX: string;
    shadowOffsetY: string;
    shadowBlurRadius: string;
    textBackgroundShape: string;
    textBackgroundColor: string;
    textBackgroundOpacity: string;
}

const FONT_SIZE_MAP: { [key: string]: number } = {
    small: 0.05,
    medium: 0.08,
    large: 0.12,
    extra_large: 0.15,
};

const OUTLINE_THICKNESS_MAP: { [key: string]: number } = {
    thin: 0.003,
    medium: 0.006,
    thick: 0.01,
};

const GLOW_RADIUS_MAP: { [key: string]: number } = {
    subtle: 10,
    normal: 20,
    wide: 35,
};

const LINE_SPACING_MAP: { [key: string]: number } = {
    tight: 1.0,
    normal: 1.2,
    loose: 1.5,
};

const loadImage = (src: string): Promise<HTMLImageElement> => {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve(img);
        img.onerror = (err) => reject(err);
        img.src = src;
    });
};

const wrapText = (
    ctx: CanvasRenderingContext2D,
    text: string,
    maxWidth: number
): string[] => {
    // Safeguard against invalid maxWidth which could cause infinite loops
    if (maxWidth <= 0) return text.split('\n');

    const finalLines: string[] = [];
    if (!text) return finalLines;

    const initialLines = text.split('\n');

    initialLines.forEach(line => {
        if (ctx.measureText(line).width <= maxWidth) {
            finalLines.push(line);
            return;
        }

        const words = line.split(' ');
        let currentLine = '';
        for (const word of words) {
            // First, check if the word itself is too long
            if (ctx.measureText(word).width > maxWidth) {
                // If there's a line being built, push it first
                if (currentLine) {
                    finalLines.push(currentLine);
                    currentLine = '';
                }
                // Break the long word character by character
                let tempWordLine = '';
                for (const char of word) {
                    const testWordLine = tempWordLine + char;
                    if (ctx.measureText(testWordLine).width > maxWidth) {
                        finalLines.push(tempWordLine);
                        tempWordLine = char;
                    } else {
                        tempWordLine = testWordLine;
                    }
                }
                currentLine = tempWordLine; // The remainder of the long word
            } else {
                // Standard word wrapping
                const testLine = currentLine ? `${currentLine} ${word}` : word;
                if (ctx.measureText(testLine).width > maxWidth) {
                    finalLines.push(currentLine);
                    currentLine = word;
                } else {
                    currentLine = testLine;
                }
            }
        }
        if (currentLine) {
            finalLines.push(currentLine);
        }
    });

    return finalLines;
};

const hexToRgba = (hex: string, opacity: number): string => {
    let c: any;
    if (/^#([A-Fa-f0-9]{3}){1,2}$/.test(hex)) {
        c = hex.substring(1).split('');
        if (c.length === 3) {
            c = [c[0], c[0], c[1], c[1], c[2], c[2]];
        }
        c = '0x' + c.join('');
        return `rgba(${[(c >> 16) & 255, (c >> 8) & 255, c & 255].join(',')},${opacity})`;
    }
    // Handle named colors by creating a dummy element
    const dummy = document.createElement('div');
    dummy.style.color = hex;
    document.body.appendChild(dummy);
    const computedColor = window.getComputedStyle(dummy).color;
    document.body.removeChild(dummy);
    return computedColor.replace(')', `, ${opacity})`).replace('rgb', 'rgba');
};

const drawTextBackground = (
    ctx: CanvasRenderingContext2D,
    lines: string[],
    x: number,
    y: number,
    fontSize: number,
    lineHeight: number,
    textAlign: CanvasTextAlign,
    options: ClientSideGenerationOptions
) => {
    if (options.textBackgroundShape === 'none' || lines.length === 0) {
        return;
    }

    const padding = fontSize * 0.4;
    const maxWidth = Math.max(...lines.map(line => ctx.measureText(line).width));
    const totalHeight = lines.length * lineHeight;

    let startX: number;
    switch (textAlign) {
        case 'center':
            startX = x - maxWidth / 2;
            break;
        case 'right':
            startX = x - maxWidth;
            break;
        case 'left':
        default:
            startX = x;
            break;
    }

    const rectX = startX - padding;
    const rectY = y - padding / 2;
    const rectWidth = maxWidth + (padding * 2);
    const rectHeight = totalHeight + padding - (lineHeight - fontSize);

    const opacity = parseInt(options.textBackgroundOpacity, 10) / 100;
    ctx.fillStyle = hexToRgba(options.textBackgroundColor, opacity);

    ctx.save();
    switch (options.textBackgroundShape) {
        case 'pill shape': {
            const radius = rectHeight / 2;
            ctx.beginPath();
            ctx.moveTo(rectX + radius, rectY);
            ctx.arcTo(rectX + rectWidth, rectY, rectX + rectWidth, rectY + rectHeight, radius);
            ctx.arcTo(rectX + rectWidth, rectY + rectHeight, rectX, rectY + rectHeight, radius);
            ctx.arcTo(rectX, rectY + rectHeight, rectX, rectY, radius);
            ctx.arcTo(rectX, rectY, rectX + rectWidth, rectY, radius);
            ctx.closePath();
            ctx.fill();
            break;
        }
        case 'subtle circle': {
            const centerX = rectX + rectWidth / 2;
            const centerY = rectY + rectHeight / 2;
            const radius = Math.max(rectWidth, rectHeight) / 2 + padding;
            ctx.beginPath();
            ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
            ctx.fill();
            break;
        }
        case 'underline bar': {
            const barHeight = Math.max(8, fontSize * 0.15);
            ctx.fillRect(rectX, rectY + rectHeight, rectWidth, barHeight);
            break;
        }
        case 'solid rectangle':
        // Fallback for AI-only shapes
        case 'ribbon / banner':
        case 'hexagon':
        case 'speech bubble':
        case 'brush stroke':
        case 'starburst shape':
        case 'abstract blob':
        default:
            ctx.fillRect(rectX, rectY, rectWidth, rectHeight);
            break;
    }
    ctx.restore();
};

const drawLinesWithEffects = (
    ctx: CanvasRenderingContext2D,
    lines: string[],
    x: number,
    y: number,
    fontSize: number,
    fontFamily: string,
    lineHeight: number,
    canvasWidth: number,
    options: ClientSideGenerationOptions
) => {
    ctx.font = `bold ${fontSize}px "${fontFamily}"`;

    // Draw background first
    drawTextBackground(ctx, lines, x, y, fontSize, lineHeight, ctx.textAlign as CanvasTextAlign, options);

    lines.forEach((line, index) => {
        const lineY = y + index * lineHeight;

        ctx.save();
        ctx.fillStyle = 'white'; 
        if (options.textEffects.drop_shadow) {
            ctx.shadowColor = options.shadowColor;
            ctx.shadowOffsetX = parseInt(options.shadowOffsetX, 10);
            ctx.shadowOffsetY = parseInt(options.shadowOffsetY, 10);
            ctx.shadowBlur = parseInt(options.shadowBlurRadius, 10);
            ctx.fillText(line, x, lineY);
        } else if (options.textEffects.glow) {
            ctx.shadowColor = options.glowColor;
            ctx.shadowBlur = GLOW_RADIUS_MAP[options.glowRadius];
            ctx.shadowOffsetX = 0;
            ctx.shadowOffsetY = 0;
            // Draw multiple times for a stronger glow effect
            for (let i = 0; i < 3; i++) {
                ctx.fillText(line, x, lineY);
            }
        }
        ctx.restore();

        if (options.textEffects.outline) {
            ctx.save();
            ctx.strokeStyle = options.outlineColor;
            const outlineWidth = OUTLINE_THICKNESS_MAP[options.outlineThickness] * canvasWidth;
            ctx.lineWidth = outlineWidth;
            
            if (options.outlineStyle === 'double') {
                ctx.strokeText(line, x, lineY);
                ctx.lineWidth = outlineWidth / 2.5; 
                ctx.strokeStyle = 'white';
                ctx.strokeText(line, x, lineY);
            } else {
                switch (options.outlineStyle) {
                    case 'dashed':
                        ctx.setLineDash([fontSize * 0.4, fontSize * 0.25]);
                        break;
                    case 'dotted':
                        ctx.setLineDash([outlineWidth, outlineWidth * 2]);
                        ctx.lineCap = 'round';
                        break;
                    case 'glow':
                        ctx.shadowColor = options.outlineColor;
                        ctx.shadowBlur = 15;
                        break;
                    default: 
                        ctx.setLineDash([]);
                        break;
                }
                ctx.strokeText(line, x, lineY);
            }
            ctx.restore();
        }

        ctx.save();
        ctx.fillStyle = 'white';
        ctx.fillText(line, x, lineY);
        ctx.restore();
    });
};

export const generateClientSideThumbnails = async (options: ClientSideGenerationOptions): Promise<string[]> => {
    // CRITICAL FIX: Ensure all specified fonts in the document are loaded and ready before rendering.
    // This prevents the canvas from falling back to a default font if the Google Font hasn't
    // been downloaded by the browser yet, ensuring visual consistency.
    await document.fonts.ready;
    
    const [width, height] = options.imageSize.split('x').map(Number);
    
    const results: string[] = [];

    for (let i = 0; i < 4; i++) {
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
            throw new Error('Could not get canvas context');
        }

        if (options.baseImage) {
            const baseImg = await loadImage(options.baseImage);
            ctx.drawImage(baseImg, 0, 0, width, height);
        } else {
            // Create a default gradient background if no image is provided
            const gradient = ctx.createLinearGradient(0, 0, 0, height);
            gradient.addColorStop(0, '#4a5568'); // gray-700
            gradient.addColorStop(1, '#1a202c'); // gray-900
            ctx.fillStyle = gradient;
            ctx.fillRect(0, 0, width, height);
        }


        const xOffsetVariation = (Math.random() - 0.5) * (width * 0.01);
        const yOffsetVariation = (Math.random() - 0.5) * (height * 0.01);
        const lineSpacingValue = LINE_SPACING_MAP[options.lineSpacing];

        // --- TITLE ---
        const titleSize = FONT_SIZE_MAP[options.titleFontSize] * height;
        const titleFontFamily = options.titleFontFamily.replace(/_/g, ' ');
        ctx.font = `bold ${titleSize}px "${titleFontFamily}"`;
        const titleMaxWidth = width * 0.9;
        const titleLines = wrapText(ctx, options.title, titleMaxWidth);
        
        ctx.textAlign = options.textAlign as CanvasTextAlign;
        ctx.textBaseline = 'top';
        const titleX = (options.textAlign === 'center' ? width / 2 : options.textAlign === 'left' ? width * 0.05 : width * 0.95) + xOffsetVariation;
        const titleY = height * 0.15 + yOffsetVariation;
        const titleLineHeight = titleSize * lineSpacingValue;

        drawLinesWithEffects(ctx, titleLines, titleX, titleY, titleSize, titleFontFamily, titleLineHeight, width, options);
        
        // --- SECONDARY TEXT ---
        const textSize = FONT_SIZE_MAP[options.textFontSize] * height;
        const textFontFamily = options.textFontFamily.replace(/_/g, ' ');
        ctx.font = `bold ${textSize}px "${textFontFamily}"`;
        const textMaxWidth = width * 0.8;
        const textLines = wrapText(ctx, options.text, textMaxWidth);
        const textLineHeight = textSize * lineSpacingValue;
        const textBlockHeight = textLines.length > 0 ? (textLines.length - 1) * textLineHeight + textSize : 0;
        
        const margin = width * 0.05;
        let textX: number, textY: number, textAlign: CanvasTextAlign, textBaseline: CanvasTextBaseline;
        
        const positionParts = (options.textPosition || 'bottom-center').split('-');
        const horizontalPart = positionParts[positionParts.length - 1];
        const verticalPart = positionParts.slice(0, positionParts.length - 1).join('-');

        // Set horizontal alignment and X position
        switch (horizontalPart) {
            case 'left':
                textAlign = 'left';
                textX = margin;
                break;
            case 'right':
                textAlign = 'right';
                textX = width - margin;
                break;
            case 'center':
            default:
                textAlign = 'center';
                textX = width / 2;
                break;
        }

        // Set vertical alignment and Y position
        switch (verticalPart) {
            case 'top':
                textBaseline = 'top';
                textY = margin;
                break;
            case 'middle':
                textBaseline = 'middle';
                textY = height / 2;
                break;
            case 'top-third':
                 textBaseline = 'middle';
                 textY = height / 3;
                 break;
            case 'bottom-third':
                 textBaseline = 'middle';
                 textY = height * (2 / 3);
                 break;
            case 'bottom':
            default:
                textBaseline = 'bottom';
                textY = height - margin;
                break;
        }

        ctx.textAlign = textAlign;
        ctx.textBaseline = 'top'; // Use top baseline for consistent line drawing calculations
        
        let adjustedY = textY;
        if (textBaseline === 'bottom') {
            adjustedY = textY - textBlockHeight;
        } else if (textBaseline === 'middle') {
            adjustedY = textY - textBlockHeight / 2;
        }

        drawLinesWithEffects(ctx, textLines, textX + xOffsetVariation, adjustedY + yOffsetVariation, textSize, textFontFamily, textLineHeight, width, options);

        results.push(canvas.toDataURL('image/png'));
    }

    return results;
};