import { HistoryEntry } from '../types';
import { resizeImage } from '../utils/imageUtils';

const HISTORY_KEY = 'thumbnail-generation-history';
const HISTORY_LIMIT = 20;

export const loadHistory = (): HistoryEntry[] => {
  try {
    const historyJson = localStorage.getItem(HISTORY_KEY);
    if (historyJson) {
      return JSON.parse(historyJson);
    }
  } catch (error) {
    console.error("Failed to load history from localStorage", error);
    // If parsing fails, clear the corrupted data
    localStorage.removeItem(HISTORY_KEY);
  }
  return [];
};

export const saveGenerationToHistory = async (newEntry: Omit<HistoryEntry, 'id'>): Promise<HistoryEntry[]> => {
  try {
    const history = loadHistory();
    
    // Create the new entry, which will then have its images compressed
    const entryWithId: HistoryEntry = { ...newEntry, id: Date.now() };

    const MAX_WIDTH = 1280;
    const MAX_HEIGHT = 720;
    
    // Compress images to save space
    if (entryWithId.baseImage) {
        entryWithId.baseImage = await resizeImage(entryWithId.baseImage, MAX_WIDTH, MAX_HEIGHT);
    }
    if (entryWithId.generatedImages && entryWithId.generatedImages.length > 0) {
        entryWithId.generatedImages = await Promise.all(
            entryWithId.generatedImages.map(img => resizeImage(img, MAX_WIDTH, MAX_HEIGHT))
        );
    }
    
    let updatedHistory = [entryWithId, ...history];
    
    // Enforce history limit
    if (updatedHistory.length > HISTORY_LIMIT) {
      updatedHistory = updatedHistory.slice(0, HISTORY_LIMIT);
    }

    // Attempt to save, with a fallback for quota errors
    try {
        localStorage.setItem(HISTORY_KEY, JSON.stringify(updatedHistory));
    } catch (e) {
        if (e instanceof DOMException && (e.name === 'QuotaExceededError' || e.code === 22)) {
            console.warn('LocalStorage quota exceeded. Removing oldest history item(s) and retrying.');
            // Iteratively remove the oldest item until it fits or history is empty.
            while (updatedHistory.length > 1) { // Keep at least the new one
                updatedHistory.pop(); // Remove the oldest
                try {
                    localStorage.setItem(HISTORY_KEY, JSON.stringify(updatedHistory));
                    // If it succeeds, break the loop
                    console.log(`Successfully saved history with ${updatedHistory.length} items.`);
                    break; 
                } catch (e2) {
                    // Continue loop if it still fails, unless it's a new error type
                    if (!(e2 instanceof DOMException && (e2.name === 'QuotaExceededError' || e2.code === 22))) {
                        throw e2; 
                    }
                }
            }
        } else {
            throw e; // Re-throw other errors
        }
    }
    
    return updatedHistory;
  } catch (error) {
    console.error("Failed to save history to localStorage", error);
    return loadHistory(); // return existing history on failure
  }
};

export const removeHistoryItem = (id: number): HistoryEntry[] => {
    try {
        const history = loadHistory();
        const updatedHistory = history.filter(item => item.id !== id);
        localStorage.setItem(HISTORY_KEY, JSON.stringify(updatedHistory));
        return updatedHistory;
    } catch (error) {
        console.error("Failed to remove item from history", error);
        return loadHistory();
    }
};

export const clearHistory = (): HistoryEntry[] => {
    try {
        localStorage.removeItem(HISTORY_KEY);
        return [];
    } catch (error) {
        console.error("Failed to clear history", error);
        return loadHistory();
    }
}