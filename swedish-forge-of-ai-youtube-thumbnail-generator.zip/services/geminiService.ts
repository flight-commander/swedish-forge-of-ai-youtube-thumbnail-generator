
import { GoogleGenAI, Modality, GenerateContentResponse, Part } from '@google/genai';
import type { GenerateThumbnailParams } from '../types';
import { fileToBase64 } from '../utils/imageUtils';

const handleGenerationError = (error: unknown): Error => {
  console.error('Error during API call:', error);
  if (error instanceof Error) {
    const errorMessage = error.message.toLowerCase();
    
    // Check for rate limit / quota errors
    if (errorMessage.includes('429') || errorMessage.includes('resource has been exhausted') || errorMessage.includes('quota')) {
        return new Error('You have exceeded your API request limit (Quota). Please wait a moment and try again, or check your usage in Google AI Studio.');
    }
    
    // Check for API key errors
    if (errorMessage.includes('api key not valid')) {
        return new Error('Invalid API Key. Please ensure your key is configured correctly in the environment.');
    }
    
    // Pass through custom, user-friendly errors that are already well-formed
    if (error.message.includes('The AI was unable to generate an image') || 
        error.message.includes('Invalid image format')) {
        return error;
    }

    // General fallback for network or other server errors
    return new Error(`Generation failed due to a network or server error. Please try again. (${error.message})`);
  }
  return new Error('An unknown error occurred while communicating with the AI service.');
};

// Utility to add a delay between operations
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));


export const generateThumbnail = async (
  prompt: string,
  base64Image?: string
): Promise<string[]> => {
  if (!process.env.API_KEY) {
    throw new Error('API_KEY environment variable is not set');
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const parts: Part[] = [{ text: prompt }];

  if (base64Image) {
    const mimeTypeMatch = base64Image.match(/^data:(.*);base64,/);
    if (!mimeTypeMatch || mimeTypeMatch.length < 2) {
      throw new Error('Invalid image format. Please upload a valid PNG or JPG file.');
    }
    const mimeType = mimeTypeMatch[1];
    const rawBase64Data = base64Image.split(',')[1];
    parts.unshift({
      inlineData: {
        data: rawBase64Data,
        mimeType: mimeType,
      },
    });
  }

  try {
    const generateSingleImage = () => 
      ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: parts,
        },
        config: {
          responseModalities: [Modality.IMAGE],
        },
      });
    
    const responses: GenerateContentResponse[] = [];
    // The free tier for Gemini often has a rate limit of 60 requests per minute.
    // We space out requests by 1 second to avoid hitting this limit when generating multiple variations.
    for (let i = 0; i < 4; i++) {
        const response = await generateSingleImage();
        responses.push(response);
        if (i < 3) { // No delay after the last request
            await delay(1000); 
        }
    }

    const images: string[] = [];
    let firstBlockReason: string | undefined = undefined;

    for (const response of responses) {
      if (response.candidates && response.candidates.length > 0 && response.candidates[0].content) {
        const part = response.candidates[0].content.parts.find(p => p.inlineData);
        if (part && part.inlineData) {
          images.push(`data:${part.inlineData.mimeType};base64,${part.inlineData.data}`);
        }
      } else if (response.promptFeedback?.blockReason && !firstBlockReason) {
        // If a generation was blocked, capture the reason to provide a better error message.
        firstBlockReason = response.promptFeedback.blockReasonMessage || `Generation was blocked due to: ${response.promptFeedback.blockReason}`;
      }
    }
    
    if (images.length === 0) {
        if (firstBlockReason) {
            throw new Error(`The AI was unable to generate an image. Reason: ${firstBlockReason}. Please adjust your input and try again.`);
        }
        throw new Error('The AI was unable to generate an image from your input. This might be due to safety restrictions or an unclear prompt. Please adjust your input and try again.');
    }
    
    // The API might return fewer than 4 images if some fail.
    // To ensure we always return 4, we can duplicate the last valid image.
    // This maintains a consistent UI experience.
    while (images.length > 0 && images.length < 4) {
      images.push(images[images.length - 1]);
    }

    return images;

  } catch (error) {
    throw handleGenerationError(error);
  }
};

// FIX: Add the missing 'generateThumbnails' function to resolve import errors in other components.
export const generateThumbnails = async (
  params: GenerateThumbnailParams,
  imageFile: File | null
): Promise<string[]> => {
  if (!process.env.API_KEY) {
    throw new Error('API_KEY environment variable is not set');
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  let prompt = `Generate a YouTube thumbnail. Title: "${params.title}". Theme: "${params.theme}". Aspect ratio: ${params.aspectRatio || '16:9'}.`;
  if (params.text) {
    prompt += ` Secondary text: "${params.text}".`;
  }
  if (params.withBanner) {
    prompt += ` The text MUST be placed on a banner for readability.`;
  }
  prompt += ` The style should be ${params.theme}.`;
  if (params.gender && params.gender !== 'any') {
      if (params.gender === 'none') {
          prompt += ` There should be no people in the image.`;
      } else if (params.gender !== 'me' && params.gender !== 'original') {
          prompt += ` Feature a ${params.gender} person.`;
      }
  }
  if (params.gender === 'original') {
      prompt += ' Use the provided image as is, only add the text on top of it.';
  } else if (params.gender === 'me' && imageFile) {
      prompt += ' Edit the provided image of a person to fit the theme.';
  }
  
  const parts: Part[] = [{ text: prompt }];

  if (imageFile) {
    const base64Image = await fileToBase64(imageFile);
    const mimeType = imageFile.type;
    if (!mimeType.startsWith('image/')) {
        throw new Error('Invalid image file type.');
    }
    const rawBase64Data = base64Image.split(',')[1];
    parts.unshift({
      inlineData: {
        data: rawBase64Data,
        mimeType: mimeType,
      },
    });
  }

  try {
    const generateSingleImage = () => 
      ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: parts,
        },
        config: {
          responseModalities: [Modality.IMAGE],
        },
      });
    
    const responses: GenerateContentResponse[] = [];
    for (let i = 0; i < 4; i++) {
        const response = await generateSingleImage();
        responses.push(response);
        if (i < 3) {
            await delay(1000); 
        }
    }

    const images: string[] = [];
    let firstBlockReason: string | undefined = undefined;

    for (const response of responses) {
      if (response.candidates && response.candidates.length > 0 && response.candidates[0].content) {
        const part = response.candidates[0].content.parts.find(p => p.inlineData);
        if (part && part.inlineData) {
          images.push(`data:${part.inlineData.mimeType};base64,${part.inlineData.data}`);
        }
      } else if (response.promptFeedback?.blockReason && !firstBlockReason) {
        firstBlockReason = response.promptFeedback.blockReasonMessage || `Generation was blocked due to: ${response.promptFeedback.blockReason}`;
      }
    }
    
    if (images.length === 0) {
        if (firstBlockReason) {
            throw new Error(`The AI was unable to generate an image. Reason: ${firstBlockReason}. Please adjust your input and try again.`);
        }
        throw new Error('The AI was unable to generate an image from your input. This might be due to safety restrictions or an unclear prompt. Please adjust your input and try again.');
    }
    
    while (images.length > 0 && images.length < 4) {
      images.push(images[images.length - 1]);
    }

    return images;

  } catch (error) {
    throw handleGenerationError(error);
  }
};

export const correctSpelling = async (textToCorrect: string): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error('API_KEY environment variable is not set');
  }
  if (!textToCorrect.trim()) {
      return textToCorrect;
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const prompt = `Correct any spelling and grammar mistakes in the following text. Return only the corrected text, with no preamble, explanation, or quotation marks. The corrected text should be a single, clean line.
Original text: "${textToCorrect}"`;

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });
    
    const correctedText = response.text.trim();
    // The model sometimes returns quotes, so we remove them.
    return correctedText.replace(/^"|"$/g, '');
  } catch (error) {
    throw handleGenerationError(error);
  }
};
