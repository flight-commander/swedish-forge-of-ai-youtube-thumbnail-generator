import React, { useState } from 'react';
import { HistoryEntry } from '../types';
import HistoryItem from './HistoryItem';
import Button from './Button';
import HistorySkeleton from './HistorySkeleton';

interface HistoryPanelProps {
  history: HistoryEntry[];
  isLoading: boolean;
  onLoad: (item: HistoryEntry) => void;
  onDelete: (id: number) => void;
  onClear: () => void;
  onImageClick: (imageUrl: string, filename: string) => void;
}

const HistoryPanel: React.FC<HistoryPanelProps> = ({ history, isLoading, onLoad, onDelete, onClear, onImageClick }) => {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <div className="w-full max-w-6xl mx-auto mt-12">
      <div className="flex justify-between items-center mb-4 px-2">
        <h2 className="text-2xl font-bold text-gray-200">Generation History</h2>
        <div className="flex items-center space-x-4">
          {!isLoading && history.length > 0 && (
            <Button onClick={onClear} variant="danger" className="py-2 px-4 text-sm w-auto">
              Clear All
            </Button>
          )}
          <button onClick={() => setIsOpen(!isOpen)} className="text-gray-400 hover:text-white p-2 rounded-full hover:bg-gray-700">
            <svg xmlns="http://www.w3.org/2000/svg" className={`h-6 w-6 transition-transform duration-300 ${isOpen ? '' : 'rotate-180'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
            <span className="sr-only">{isOpen ? 'Collapse history' : 'Expand history'}</span>
          </button>
        </div>
      </div>
      {isOpen && (
        <div className={`transition-opacity duration-500 ${isLoading ? 'opacity-0' : 'opacity-100'}`}>
          {isLoading ? (
            <div className="space-y-4">
              <HistorySkeleton />
              <HistorySkeleton />
            </div>
          ) : history.length === 0 ? (
            <div className="text-center py-12 bg-gray-800/50 rounded-lg border border-gray-700">
              <p className="text-gray-500">No history yet. Generate some thumbnails to see them here.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {history.map(item => (
                <HistoryItem 
                  key={item.id} 
                  item={item} 
                  onLoad={onLoad} 
                  onDelete={onDelete} 
                  onImageClick={onImageClick}
                />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default HistoryPanel;