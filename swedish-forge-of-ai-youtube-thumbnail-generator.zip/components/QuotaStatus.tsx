
import React from 'react';

interface QuotaStatusProps {
  generationsLeft: number;
}

const QuotaStatus: React.FC<QuotaStatusProps> = ({ generationsLeft }) => {
  const isInfinite = !isFinite(generationsLeft);
  const displayValue = isInfinite ? 'N/A' : generationsLeft;
  const helpText = isInfinite ? '(Client-side has no API cost)' : '(Based on current settings)';

  return (
    <div className="text-sm text-gray-400 bg-gray-900/30 p-3 rounded-lg border border-gray-700 flex justify-between items-center">
      <div>
        <span>Generations left this minute: </span>
        <span className="font-bold text-lg text-white ml-2">{displayValue}</span>
      </div>
      <span className="text-xs text-gray-500">{helpText}</span>
    </div>
  );
};

export default QuotaStatus;
