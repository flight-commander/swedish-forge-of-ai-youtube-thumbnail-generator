import React, { useRef } from 'react';

interface ImageInputProps {
  onImagesSelect: (files: File[]) => void;
  onImageRemove: (index: number) => void;
  uploadedFiles: File[];
  previews: string[];
}

const ImageInput: React.FC<ImageInputProps> = ({ 
  onImagesSelect,
  onImageRemove,
  uploadedFiles,
  previews, 
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      onImagesSelect(Array.from(files));
    }
    // Reset file input to allow re-uploading the same file
    if (event.target) {
        event.target.value = '';
    }
  };

  const handleAreaClick = () => {
    fileInputRef.current?.click();
  };
  
  const handleRemoveClick = (e: React.MouseEvent, index: number) => {
    e.stopPropagation();
    onImageRemove(index);
  }

  return (
    <div>
      <label className="block mb-2 text-sm font-medium text-gray-300">
        Base Image (Optional)
      </label>
      <div
        onClick={handleAreaClick}
        className="mt-1 flex flex-col items-center p-6 border-2 border-gray-600 border-dashed rounded-md cursor-pointer hover:border-blue-500 transition duration-300"
      >
        {previews.length > 0 ? (
          <div className="w-full grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {previews.map((preview, index) => (
              <div 
                key={index} 
                className="relative group rounded-md overflow-hidden ring-2 ring-transparent"
              >
                <img src={preview} alt={`Preview ${index + 1}`} className="w-full h-24 object-cover" />
                
                <button
                  onClick={(e) => handleRemoveClick(e, index)}
                  className="absolute top-1 right-1 bg-black/50 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 hover:bg-red-600 transition-all duration-200 z-10"
                  aria-label={`Remove image ${index + 1}`}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-1 text-center py-4">
            <svg
              className="mx-auto h-12 w-12 text-gray-500"
              stroke="currentColor"
              fill="none"
              viewBox="0 0 48 48"
              aria-hidden="true"
            >
              <path
                d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <div className="flex text-sm text-gray-400 justify-center">
              <p className="pl-1">Upload an image to edit</p>
            </div>
          </div>
        )}
         <div className="mt-4 text-center text-sm text-gray-500">
            <p>{previews.length > 0 ? 'Click here to add more images to edit.' : 'Or, leave empty to generate an image from scratch.'}</p>
         </div>
        <input
          ref={fileInputRef}
          id="file-upload"
          name="file-upload"
          type="file"
          className="sr-only"
          accept="image/png, image/jpeg"
          onChange={handleFileChange}
          multiple
        />
      </div>
    </div>
  );
};

export default ImageInput;