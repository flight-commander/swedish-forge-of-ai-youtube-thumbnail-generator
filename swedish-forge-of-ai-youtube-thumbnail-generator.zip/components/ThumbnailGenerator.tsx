

import React, { useState } from 'react';
// FIX: Corrected the function import from 'generateThumbnail' to 'generateThumbnails'.
import { generateThumbnails } from '../services/geminiService';
// FIX: Importing GenerateThumbnailParams to correctly type the parameters for the service call.
import { AspectRatio, ThumbnailStyle, GenerateThumbnailParams } from '../types';
import { ASPECT_RATIO_OPTIONS, THUMBNAIL_STYLE_OPTIONS } from '../constants';
import Spinner from './Spinner';
import { DownloadIcon, SparklesIcon } from './icons/Icons';

const ThumbnailGenerator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>(AspectRatio.SixteenNine);
  const [style, setStyle] = useState<ThumbnailStyle>(ThumbnailStyle.Photorealistic);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      setError('Please enter a description for your thumbnail.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setGeneratedImage(null);

    try {
      // FIX: Adapted the call to use the `generateThumbnails` function by creating a params object.
      // This component's UI doesn't map to all service options, so defaults are used.
      const params: GenerateThumbnailParams = {
        title: prompt,
        theme: style,
        text: '',
        videoUrl: '',
        gender: 'any',
        withBanner: false,
        // FIX: Add missing 'aspectRatio' property to satisfy the GenerateThumbnailParams type.
        aspectRatio: aspectRatio,
      };
      const imageUrls = await generateThumbnails(params, null);
      
      // The service returns an array of images, so we'll display the first one.
      if (imageUrls && imageUrls.length > 0) {
        setGeneratedImage(imageUrls[0]);
      } else {
        setError("The AI did not return any images.");
      }
    } catch (err) {
        if (err instanceof Error) {
            setError(err.message);
        } else {
            setError('An unexpected error occurred.');
        }
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleDownload = () => {
    if (!generatedImage) return;
    const link = document.createElement('a');
    link.href = generatedImage;
    link.download = 'thumbnail.jpeg';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-4xl mx-auto flex flex-col lg:flex-row gap-8">
      {/* Left side: Controls */}
      <div className="w-full lg:w-1/3 bg-slate-800 p-6 rounded-lg shadow-lg flex flex-col gap-6">
        <div>
          <label htmlFor="prompt" className="block text-sm font-medium text-slate-300 mb-2">
            1. Describe your thumbnail
          </label>
          <textarea
            id="prompt"
            rows={5}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="w-full bg-slate-900 border border-slate-600 rounded-md p-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-200"
            placeholder="e.g., A scientist discovering a glowing planet in space"
            disabled={isLoading}
          />
        </div>

        <div>
          <label htmlFor="style" className="block text-sm font-medium text-slate-300 mb-2">
            2. Choose a style
          </label>
          <select
            id="style"
            value={style}
            onChange={(e) => setStyle(e.target.value as ThumbnailStyle)}
            className="w-full bg-slate-900 border border-slate-600 rounded-md p-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-200"
            disabled={isLoading}
          >
            {THUMBNAIL_STYLE_OPTIONS.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
        
        <div>
          <label htmlFor="aspectRatio" className="block text-sm font-medium text-slate-300 mb-2">
            3. Select aspect ratio
          </label>
          <select
            id="aspectRatio"
            value={aspectRatio}
            onChange={(e) => setAspectRatio(e.target.value as AspectRatio)}
            className="w-full bg-slate-900 border border-slate-600 rounded-md p-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-200"
            disabled={isLoading}
          >
            {ASPECT_RATIO_OPTIONS.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>

        <button
          onClick={handleGenerate}
          disabled={isLoading}
          className="w-full mt-2 flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-900 disabled:text-slate-400 text-white font-bold py-3 px-4 rounded-lg transition duration-300"
        >
          {isLoading ? <><Spinner /> Generating...</> : <><SparklesIcon /> Generate</>}
        </button>
      </div>

      {/* Right side: Image display */}
      <div className="w-full lg:w-2/3 bg-slate-800 p-6 rounded-lg shadow-lg flex flex-col justify-center items-center min-h-[400px]">
        {isLoading && (
          <div className="text-center">
            <Spinner large={true} />
            <p className="mt-4 text-slate-400 animate-pulse">Creating your masterpiece...</p>
          </div>
        )}

        {error && (
          <div className="text-center text-red-400 bg-red-900/50 p-4 rounded-lg">
            <h3 className="font-bold">Generation Failed</h3>
            <p className="text-sm">{error}</p>
          </div>
        )}

        {!isLoading && !generatedImage && !error && (
          <div className="text-center text-slate-500">
             <SparklesIcon className="mx-auto h-12 w-12 text-slate-600" />
            <p className="mt-4">Your generated thumbnail will appear here.</p>
          </div>
        )}

        {generatedImage && (
          <div className="w-full flex flex-col items-center gap-4">
            <img 
              src={generatedImage} 
              alt="Generated thumbnail" 
              className="rounded-lg shadow-2xl w-full object-contain"
            />
            <button
                onClick={handleDownload}
                className="w-full sm:w-auto flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded-lg transition duration-300"
            >
                <DownloadIcon /> Download
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ThumbnailGenerator;