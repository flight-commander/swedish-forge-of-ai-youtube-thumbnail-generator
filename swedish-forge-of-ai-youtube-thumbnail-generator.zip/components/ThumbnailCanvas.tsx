
import React, { forwardRef } from 'react';
// FIX: Correctly import ImageIcon from its dedicated file.
import ImageIcon from './icons/ImageIcon';

interface ThumbnailCanvasProps {
  image: string | null;
  title: string;
}

const ThumbnailCanvas = forwardRef<HTMLDivElement, ThumbnailCanvasProps>(({ image, title }, ref) => {
  return (
    <div 
      ref={ref} 
      className="w-full aspect-video bg-gray-700/50 rounded-lg overflow-hidden relative shadow-lg"
    >
      {image ? (
        <img src={image} alt="Thumbnail background" className="w-full h-full object-cover" />
      ) : (
        <div className="w-full h-full flex flex-col items-center justify-center text-gray-400">
            <ImageIcon className="w-16 h-16 mb-2" />
            <p>Your thumbnail preview will appear here</p>
            <p className="text-sm text-gray-500">Upload an image or generate one with AI</p>
        </div>
      )}
      <div className="absolute inset-0 p-4 sm:p-6 md:p-8 flex flex-col justify-end">
        <h3 
          className="text-white font-extrabold text-2xl sm:text-3xl md:text-5xl tracking-tighter"
          style={{ textShadow: '0px 4px 8px rgba(0, 0, 0, 0.8)' }}
        >
          {title}
        </h3>
      </div>
    </div>
  );
});

ThumbnailCanvas.displayName = 'ThumbnailCanvas';

export default ThumbnailCanvas;