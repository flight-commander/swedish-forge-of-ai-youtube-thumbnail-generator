
import React from 'react';

interface ToggleSwitchProps {
  id: string;
  label: string;
  enabled: boolean;
  onChange: (enabled: boolean) => void;
  helpText?: string;
  disabled?: boolean;
}

const ToggleSwitch: React.FC<ToggleSwitchProps> = ({ id, label, enabled, onChange, helpText, disabled = false }) => {
  return (
    <div className={disabled ? 'opacity-50' : ''}>
        <div className="flex items-center justify-between">
            <span className="flex-grow flex flex-col">
                <label htmlFor={id} className={`text-sm font-medium text-gray-300 ${disabled ? 'cursor-not-allowed' : ''}`}>
                {label}
                </label>
                {helpText && <p className="text-xs text-gray-500">{helpText}</p>}
            </span>
            <button
                type="button"
                id={id}
                className={`${
                enabled ? 'bg-blue-600' : 'bg-gray-600'
                } relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-blue-500 disabled:bg-gray-700 disabled:cursor-not-allowed`}
                role="switch"
                aria-checked={enabled}
                onClick={() => !disabled && onChange(!enabled)}
                disabled={disabled}
            >
                <span
                className={`${
                    enabled ? 'translate-x-6' : 'translate-x-1'
                } inline-block w-4 h-4 transform bg-white rounded-full transition-transform`}
                />
            </button>
        </div>
    </div>
  );
};

export default ToggleSwitch;
