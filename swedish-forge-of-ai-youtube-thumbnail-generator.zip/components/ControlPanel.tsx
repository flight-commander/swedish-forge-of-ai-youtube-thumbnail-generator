
import React, { useRef } from 'react';
import { UploadIcon, LoaderIcon } from './icons';

interface ControlPanelProps {
  title: string;
  onTitleChange: (title: string) => void;
  onImageUpload: (base64: string | null) => void;
  onGenerate: () => void;
  isLoading: boolean;
}

const ControlPanel: React.FC<ControlPanelProps> = ({
  title,
  onTitleChange,
  onImageUpload,
  onGenerate,
  isLoading,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onImageUpload(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="bg-gray-800 rounded-lg p-6 space-y-6 shadow-2xl">
      <div>
        <label htmlFor="title" className="block text-sm font-medium text-cyan-400 mb-1">
          Video Title
        </label>
        <input
          type="text"
          id="title"
          value={title}
          onChange={(e) => onTitleChange(e.target.value)}
          placeholder="e.g., My Epic Gaming Montage"
          className="block w-full bg-gray-700 border-gray-600 rounded-md shadow-sm focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm text-white py-2 px-3"
        />
        <p className="mt-2 text-xs text-gray-400">
          The AI will use this title to generate the perfect thumbnail concept.
        </p>
      </div>

      <div>
        <span className="block text-sm font-medium text-cyan-400 mb-1">
          Background Image (Optional)
        </span>
        <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-600 border-dashed rounded-md">
          <div className="space-y-1 text-center">
            <UploadIcon className="mx-auto h-12 w-12 text-gray-400" />
            <div className="flex text-sm text-gray-400">
              <button
                type="button"
                onClick={handleUploadClick}
                className="relative cursor-pointer bg-transparent rounded-md font-medium text-cyan-500 hover:text-cyan-400 focus-within:outline-none"
              >
                <span>Upload a file</span>
                <input
                  ref={fileInputRef}
                  id="file-upload"
                  name="file-upload"
                  type="file"
                  className="sr-only"
                  accept="image/png, image/jpeg, image/webp"
                  onChange={handleImageChange}
                />
              </button>
              <p className="pl-1">or drag and drop</p>
            </div>
            <p className="text-xs text-gray-500">PNG, JPG, WEBP up to 10MB</p>
          </div>
        </div>
      </div>

      <button
        onClick={onGenerate}
        disabled={isLoading}
        className="w-full inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-cyan-600 hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500 disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors"
      >
        {isLoading ? (
          <>
            <LoaderIcon className="animate-spin -ml-1 mr-3 h-5 w-5" />
            Generating...
          </>
        ) : (
          '✨ Generate with AI'
        )}
      </button>
    </div>
  );
};

export default ControlPanel;
