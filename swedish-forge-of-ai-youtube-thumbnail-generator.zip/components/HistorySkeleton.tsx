import React from 'react';
import SkeletonLoader from './SkeletonLoader';

const HistorySkeleton: React.FC = () => {
  return (
    <div className="bg-gray-800 p-4 rounded-lg border border-gray-700 space-y-4 animate-pulse">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <div className="h-6 bg-gray-700 rounded w-1/3 mb-4"></div>
          <div className="space-y-3">
            <div className="h-4 bg-gray-700 rounded w-3/4"></div>
            <div className="h-4 bg-gray-700 rounded w-full"></div>
            <div className="h-4 bg-gray-700 rounded w-5/6"></div>
            <div className="h-4 bg-gray-700 rounded w-1/2"></div>
          </div>
          <div className="mt-4">
            <div className="h-5 bg-gray-700 rounded w-1/4 mb-2"></div>
            <div className="w-full aspect-video bg-gray-700 rounded-md"></div>
          </div>
        </div>
        <div>
          <div className="h-6 bg-gray-700 rounded w-1/2 mb-4"></div>
          <div className="grid grid-cols-2 gap-2">
            <div className="w-full aspect-video bg-gray-700 rounded-md"></div>
            <div className="w-full aspect-video bg-gray-700 rounded-md"></div>
            <div className="w-full aspect-video bg-gray-700 rounded-md"></div>
            <div className="w-full aspect-video bg-gray-700 rounded-md"></div>
          </div>
        </div>
      </div>
      <div className="flex space-x-4 pt-2">
        <div className="h-10 bg-gray-700 rounded-lg w-full"></div>
        <div className="h-10 bg-gray-700 rounded-lg w-full"></div>
      </div>
    </div>
  );
};

export default HistorySkeleton;
