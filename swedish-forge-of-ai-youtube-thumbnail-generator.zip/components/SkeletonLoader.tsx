import React from 'react';

const SkeletonLoader: React.FC = () => {
  return (
    <div className="w-full aspect-video bg-gray-700/50 rounded-lg animate-pulse"></div>
  );
};

export default SkeletonLoader;
