
import React, { useEffect } from 'react';
import Button from './Button';

interface ImageModalProps {
  imageUrl: string;
  onClose: () => void;
  onDownload: () => void;
}

const ImageModal: React.FC<ImageModalProps> = ({ imageUrl, onClose, onDownload }) => {
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden'; // Prevent background scrolling

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = ''; // Restore scrolling
    };
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-80 flex justify-center items-center z-50 p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="relative bg-gray-900 rounded-lg shadow-xl p-4 w-full max-w-4xl max-h-full flex flex-col"
        onClick={(e) => e.stopPropagation()} // Prevent closing modal when clicking inside
      >
        <button
          onClick={onClose}
          className="absolute top-2 right-2 text-gray-400 hover:text-white bg-gray-800 rounded-full p-2 focus:outline-none focus:ring-2 focus:ring-white z-10"
          aria-label="Close"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <div className="flex-grow flex items-center justify-center overflow-hidden mb-4">
            <img
                src={imageUrl}
                alt="Enlarged thumbnail"
                className="max-w-full max-h-[75vh] object-contain"
            />
        </div>
        
        <div className="flex-shrink-0">
            <Button onClick={onDownload} variant="primary" className="w-auto px-8 mx-auto">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
                Download
            </Button>
        </div>
      </div>
    </div>
  );
};

export default ImageModal;
