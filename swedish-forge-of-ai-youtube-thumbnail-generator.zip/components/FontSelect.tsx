import React, { useState, useRef, useEffect } from 'react';

interface FontOption {
  value: string;
  label: string;
}

interface FontSelectProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  id: string;
  options: FontOption[];
}

const FontSelect: React.FC<FontSelectProps> = ({ label, value, onChange, id, options }) => {
  const [isOpen, setIsOpen] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);
  
  const selectedOption = options.find(opt => opt.value === value) || options.find(opt => opt.value === 'impact') || options[0];

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [wrapperRef]);

  const handleSelect = (option: FontOption) => {
    onChange(option.value);
    setIsOpen(false);
  };
  
  const getFontFamily = (label: string) => {
    if (label.includes('(')) return 'system-ui, sans-serif'; // Default font for non-font labels
    return `'${label}', sans-serif`;
  }

  return (
    <div ref={wrapperRef} className="relative">
      <label htmlFor={id} className="block mb-2 text-sm font-medium text-gray-300">
        {label}
      </label>
      <button
        type="button"
        id={id}
        onClick={() => setIsOpen(!isOpen)}
        className="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 text-left flex justify-between items-center transition duration-300"
        aria-haspopup="listbox"
        aria-expanded={isOpen}
      >
        <span style={{ fontFamily: getFontFamily(selectedOption.label), fontSize: '1.1rem' }}>
            {selectedOption.label}
        </span>
        <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 text-gray-400 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      {isOpen && (
        <ul
          className="absolute z-10 w-full bg-gray-800 border border-gray-600 rounded-lg mt-1 max-h-60 overflow-y-auto shadow-lg"
          role="listbox"
        >
          {options.map((option) => (
            <li
              key={option.value}
              onClick={() => handleSelect(option)}
              className="px-4 py-2 text-white hover:bg-blue-600/50 cursor-pointer transition-colors duration-150"
              role="option"
              aria-selected={value === option.value}
              style={{ fontFamily: getFontFamily(option.label), fontSize: '1.1rem' }}
            >
              {option.label}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default FontSelect;
