import React from 'react';

interface CheckboxInputProps {
  label: string;
  checked: boolean;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  id: string;
  name: string;
}

const CheckboxInput: React.FC<CheckboxInputProps> = ({ label, checked, onChange, id, name }) => {
  return (
    <div className="flex items-center">
      <input
        id={id}
        name={name}
        type="checkbox"
        checked={checked}
        onChange={onChange}
        className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded focus:ring-blue-600 ring-offset-gray-800 focus:ring-2"
      />
      <label htmlFor={id} className="ml-2 text-sm font-medium text-gray-300">
        {label}
      </label>
    </div>
  );
};

export default CheckboxInput;
