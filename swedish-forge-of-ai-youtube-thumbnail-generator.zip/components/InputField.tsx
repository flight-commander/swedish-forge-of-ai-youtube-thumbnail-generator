import React from 'react';

interface InputFieldProps {
  id: string;
  label: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onBlur?: () => void;
  placeholder: string;
  required?: boolean;
  isLoading?: boolean;
}

export const InputField: React.FC<InputFieldProps> = ({ id, label, value, onChange, onBlur, placeholder, required = false, isLoading = false }) => (
  <div>
    <label htmlFor={id} className="block text-sm font-medium text-gray-400 mb-2">
      {label} {required && <span className="text-red-400">*</span>}
    </label>
    <div className="relative">
      <input
        type="text"
        id={id}
        name={id}
        value={value}
        onChange={onChange}
        onBlur={onBlur}
        placeholder={placeholder}
        required={required}
        className="w-full bg-gray-700 border border-gray-600 rounded-md shadow-sm py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
      />
      {isLoading && (
        <div className="absolute inset-y-0 right-0 flex items-center pr-3">
          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-indigo-400"></div>
        </div>
      )}
    </div>
  </div>
);
