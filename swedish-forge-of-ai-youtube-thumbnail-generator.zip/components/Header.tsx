import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="w-full max-w-5xl mx-auto text-center mb-12">
      <h1 className="text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-600">
        AI YouTube Thumbnail Generator
      </h1>
      <p className="mt-4 text-lg text-gray-400">
        Create stunning, clickable thumbnails in seconds. Edit your own image or generate one from scratch.
      </p>
    </header>
  );
};

export default Header;