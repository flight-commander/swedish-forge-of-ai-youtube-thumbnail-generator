import React from 'react';
import { HistoryEntry } from '../types';
import Button from './Button';

interface HistoryItemProps {
  item: HistoryEntry;
  onLoad: (item: HistoryEntry) => void;
  onDelete: (id: number) => void;
  onImageClick: (imageUrl: string, filename: string) => void;
}

const Detail: React.FC<{ label: string; children: React.ReactNode }> = ({ label, children }) => (
  <p className="text-sm">
    <strong className="text-gray-400">{label}:</strong>
    <span className="text-gray-300 ml-1.5">{children}</span>
  </p>
);

const HistoryItem: React.FC<HistoryItemProps> = ({ item, onLoad, onDelete, onImageClick }) => {
  const formatFontName = (font: string | undefined) => {
    if (!font || font === 'default') return 'Default (AI Choice)';
    return font.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  };
  
  const capitalize = (s: string | undefined) => {
    if (!s) return '';
    const formatted = s.replace(/_/g, ' ');
    return formatted.charAt(0).toUpperCase() + formatted.slice(1);
  };

  return (
    <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
        <div className="flex flex-col md:flex-row gap-4">
            {/* Left side: Details */}
            <div className="flex-1 space-y-3 break-words">
                <div>
                    <h3 className="font-bold text-lg text-gray-200 truncate" title={item.title}>{item.title}</h3>
                    <p className="text-xs text-gray-500">{new Date(item.id).toLocaleString()}</p>
                </div>
                <Detail label="Text">{item.text}</Detail>
                <Detail label="Theme">{item.theme}</Detail>
                <Detail label="Mode">
                    <span className={`px-2 py-0.5 rounded-full text-xs ${item.useAiImageEditing ?? true ? 'bg-blue-900/50 text-blue-300' : 'bg-green-900/50 text-green-300'}`}>
                        {item.useAiImageEditing ?? true ? 'AI Image Editing' : 'Text Overlay'}
                    </span>
                </Detail>
            </div>
            {/* Right side: Images */}
            <div className="md:w-1/2 flex-shrink-0">
                <div className="grid grid-cols-3 gap-2">
                    <div className="col-span-1">
                        <h4 className="font-semibold text-gray-300 text-sm mb-1.5 text-center">Base</h4>
                         {item.baseImage ? (
                            <img 
                                src={item.baseImage} 
                                alt="Base" 
                                className="w-full aspect-video object-cover rounded-md bg-gray-900 cursor-pointer transition-transform duration-200 hover:scale-105 hover:ring-2 ring-blue-500"
                                onClick={() => onImageClick(item.baseImage as string, `history-${item.id}-base.png`)}
                            />
                         ) : (
                            <div className="w-full aspect-video flex items-center justify-center rounded-md bg-gray-900/70 text-gray-500 text-xs text-center">
                                Generated from scratch
                            </div>
                         )}
                    </div>
                    <div className="col-span-2">
                         <h4 className="font-semibold text-gray-300 text-sm mb-1.5 text-center">Results</h4>
                        <div className="grid grid-cols-2 gap-2">
                            {item.generatedImages.slice(0, 4).map((img, index) => (
                                <img 
                                    key={index} 
                                    src={img} 
                                    alt={`Generated ${index + 1}`} 
                                    className="w-full aspect-video object-cover rounded-md bg-gray-900 cursor-pointer transition-transform duration-200 hover:scale-105 hover:ring-2 ring-blue-500"
                                    onClick={() => onImageClick(img, `history-${item.id}-result-${index + 1}.png`)}
                                />
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
      <div className="flex space-x-4 pt-4 mt-4 border-t border-gray-700/50">
        <Button onClick={() => onLoad(item)} variant="secondary" className="text-sm py-2">
          Load
        </Button>
        <Button onClick={() => onDelete(item.id)} variant="danger" className="text-sm py-2">
          Delete
        </Button>
      </div>
    </div>
  );
};

export default HistoryItem;
